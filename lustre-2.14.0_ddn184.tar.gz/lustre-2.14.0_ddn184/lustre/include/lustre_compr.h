/* GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */

/*
 * Copyright (c) 2023, DataDirect Networks Inc, all rights reserved.
 * Author: Artem Blagodarenko <ablagodarenko@whamcloud.com>
 */
#ifndef _LUSTRE_COMPR_H_
#define _LUSTRE_COMPR_H_

#include <linux/crypto.h>
#define LL_COMPR_GAP 4096

int alloc_compr(struct client_obd *cli, enum ll_compr_type *type,
		unsigned int *lvl, struct crypto_comp **cc);
int alloc_decompr(const char *obd_name, enum ll_compr_type *type,
		  unsigned int *lvl, struct crypto_comp **cc);
int compress_chunk(const char *obd_name, struct crypto_comp *cc,
		   const unsigned char *in, unsigned int in_len,
		   unsigned char *out, unsigned int *out_len,
		   enum ll_compr_type type, unsigned int lvl,
		   unsigned int chunk_bits);

static inline struct page *mem_to_page(void *addr)
{
	if (!is_vmalloc_addr(addr))
		return virt_to_page(addr);

	return vmalloc_to_page(addr);
}

int is_chunk_start(struct page *page, struct ll_compr_hdr *ret_header, int *rc);

int decompress_chunk(const char *obd_name, struct crypto_comp *cc,
		     unsigned char *in, unsigned int in_len,
		     unsigned char *out, unsigned int *out_len,
		     enum ll_compr_type type, unsigned int lvl);

int compress_str2type(char *s_type, enum ll_compr_type *type,
		      char *s_level, int *level);

#endif /* _LUSTRE_COMPR_H_ */
