/*
 * GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */
/*
 * Copyright (c) 2022 DataDirect Networks
 */
/*
 * This file is part of Lustre, http://www.lustre.org/
 */

/* Test various compression/decompression routines as exported via the
 * kernel Crypto API.
 */

#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/version.h>
#include <linux/crypto.h>
#ifdef HAVE_CRYPTO_INIT_WAIT
#include <linux/scatterlist.h>
#include <crypto/acompress.h>
#endif
#include <linux/random.h>
#include <lustre_crypto.h>
#include <obd_support.h>

/* Random ID passed by userspace, and printed in messages, used to
 * separate different runs of that module.
 */
static int run_id;
module_param(run_id, int, 0644);
MODULE_PARM_DESC(run_id, "run ID");

/* Path to file to compress passed by userspace. */
static char *input_file;
module_param(input_file, charp, 0644);
MODULE_PARM_DESC(input_file, "path to file to compress");

#define PREFIX "lustre_kcompr_%u: "
#define COMPR_CHUNK_SIZE (1 << 16) /* 64 KB */

struct compr_desc {
	char *cd_name;  /* compression alg name */
	int   cd_level; /* compression level */
};

/* Compression algorithms to test */
/* For LZ4, cd_level is interpreted as an "acceleration" factor. The larger the
 * acceleration value, the faster the algorithm, but the lesser the compression.
 * An acceleration value of "1" is the default.
 * This acceleration factor is taken into account only by the Lustre-modified
 * lz4 module.
 */
/* For LZ4HC, cd_level is interpreted as a compression level. The higher the
 * level value, the better the compression, but the slower the algorithm.
 * A level value of "9" is the default.
 * This acceleration factor is taken into account only by the Lustre-modified
 * lz4hc module.
 */
/* To conform to values that can be stored in the Lustre file layout (limited to
 * 4 bits) we use levels between 0 and 15, 0 meaning 'use default'. Then this
 * level is mapped to actual acceleration factor or compression level in the
 * corresponding compression module. See lustre/lz4/lz4.h for mapping in place
 * for lz4, and lustre/zstd/zstd.c for zstd/zstdfast.
 */
static struct compr_desc compr_algs[] = {
	{ .cd_name = "lz4",	.cd_level = 1 },
	{ .cd_name = "lz4",	.cd_level = 4 },
	{ .cd_name = "lz4",	.cd_level = 9 },
	{ .cd_name = "lz4",	.cd_level = 15 },
	{ .cd_name = "lz4hc",	.cd_level = 1 },
	{ .cd_name = "lz4hc",	.cd_level = 3 },
	{ .cd_name = "lz4hc",	.cd_level = 8 },
	{ .cd_name = "lz4hc",	.cd_level = 15 },
	{ .cd_name = "lzo",	.cd_level = -1 },
	/* deflate is the crypto module implementing zlib compression (gzip) */
	{ .cd_name = "deflate",	.cd_level = 1 },
	{ .cd_name = "deflate",	.cd_level = 6 },
	{ .cd_name = "deflate",	.cd_level = 9 },
	{ .cd_name = "zstd",	.cd_level = 0 },
	{ .cd_name = "zstd",	.cd_level = 1 },
	{ .cd_name = "zstd",	.cd_level = 10 },
	{ .cd_name = "zstd",	.cd_level = 15 },
	{ .cd_name = "zstdfast", .cd_level = 1 },
	{ .cd_name = "zstdfast", .cd_level = 5 },
	{ .cd_name = "zstdfast", .cd_level = 12 },
	{ .cd_name = "zstdfast", .cd_level = 15 },
};

static int fill_input_from_file(char *filepath, struct page *page, size_t count)
{
	struct file *filp;
	loff_t pos = 0;
	void *pageaddr;
	int err = 0;

	pageaddr = kmap(page);
	filp = filp_open(filepath, O_RDONLY, 0);
	if (IS_ERR_OR_NULL(filp)) {
		err = PTR_ERR(filp);
		filp = NULL;
		goto out;
	}

	err = cfs_kernel_read(filp, pageaddr, count, &pos);
	if (err < 0)
		goto out;

out:
	if (filp)
		filp_close(filp, NULL);
	kunmap(page);
	return err;
}

static int fill_input_with_rand(struct page *page, size_t count)
{
	char randbuf1[67], randbuf2[14];
	void *pageaddr;
	char *p;

	pageaddr = kmap(page);
	/* write binary test data into pages */
	p = pageaddr;
	get_random_bytes(randbuf1, sizeof(randbuf1));
	while (p + sizeof(randbuf1) - (char *)pageaddr < count) {
		memcpy(p, randbuf1, sizeof(randbuf1));
		p += sizeof(randbuf1);
	}
	p = pageaddr;
	while (p + sizeof(randbuf2) - (char *)pageaddr < count) {
		get_random_bytes(randbuf2, sizeof(randbuf2));
		memcpy(p, randbuf2, sizeof(randbuf2));
		p += sizeof(randbuf2) + get_random_u32_below(1 << 13);
	}
	kunmap(page);
	return count;
}

/* compress and decompress, generic variant */
static int test_comp_compress_decompress(struct page *in_page,
					 unsigned int order,
					 char *compr_name, int level)
{
	void *inpageaddr = NULL, *comppageaddr = NULL, *decomppageaddr = NULL;
	struct page *comp_out_page = NULL, *decomp_out_page = NULL;
	unsigned int in_len = 1 << (PAGE_SHIFT + order);
	unsigned int comp_len = in_len, decomp_len = in_len;
	unsigned int curr_len, curr_comp_len;
	void *incurrpageaddr, *outcurrpageaddr;
	unsigned int chunk_size = COMPR_CHUNK_SIZE;
	struct crypto_comp *cc = NULL;
	ktime_t started, finished;
	u64 usdelta, currusdelta;
	int err = -1;

	/* allocate 1 << order contiguous pages for compression output */
	comp_out_page = alloc_pages(GFP_KERNEL, order);
	if (!comp_out_page) {
		pr_err(PREFIX "ENOMEM cannot allocate comp_out_page\n", run_id);
		goto free;
	}
	/* allocate 1 << order contiguous pages for decompression output */
	decomp_out_page = alloc_pages(GFP_KERNEL, order);
	if (!decomp_out_page) {
		pr_err(PREFIX "ENOMEM cannot allocate decomp_out_page\n",
		       run_id);
		goto free;
	}

	/* For lz4/lz4hc, lgzip, lzstd, try to use our built-in modules.
	 * Do not check request_module ret code, this is best effort
	 * as it will fail back to kernel's deflate.
	 */
	if (strcmp(compr_name, "lz4") == 0)
		request_module(LLZ4FAST_MOD_NAME);
	else if (strcmp(compr_name, "lz4hc") == 0)
		request_module(LLZ4HC_MOD_NAME);
	else if (strcmp(compr_name, "deflate") == 0)
		request_module(LGZIP_MOD_NAME);
	else if (strncmp(compr_name, "zstd", strlen("zstd")) == 0)
		request_module(LZSTD_MOD_NAME);
	cc = crypto_alloc_comp(compr_name, 0, 0);
	if (IS_ERR(cc)) {
		pr_err(PREFIX
		       "ERROR cannot initialize compressor %s, error %ld\n",
		       run_id, compr_name, PTR_ERR(cc));
		cc = NULL;
		goto free;
	}

	if (level != -1)
		ll_crypto_comp_set_level(cc, level);

	inpageaddr = kmap(in_page);
	comppageaddr = kmap(comp_out_page);

	/* Try compression by COMPR_CHUNK_SIZE chunks only if multiple */
	if (!(in_len & (COMPR_CHUNK_SIZE - 1))) {
		/* loop on chunk_size, from COMPR_CHUNK_SIZE
		 * and double each time
		 */
		while (chunk_size < in_len) {
			incurrpageaddr = inpageaddr;
			outcurrpageaddr = comppageaddr;
			curr_len = in_len;
			currusdelta = 0;
			curr_comp_len = 0;
			/* compress input data, one chunk at a time */
			while (curr_len > 0) {
				comp_len = chunk_size;
				started = ktime_get();
				err = crypto_comp_compress(cc, incurrpageaddr,
							   chunk_size,
							   outcurrpageaddr,
							   &comp_len);
				finished = ktime_get();
				if (err || comp_len >= chunk_size) {
					/* If compress returns error, or if
					 * output len is greater than input len,
					 * it means it is not worth compressing.
					 * So just copy input into output.
					 */
					pr_err(PREFIX "cannot compress %d bytes, compressor %s (out len %d), leave uncompressed\n",
					       run_id, chunk_size, compr_name,
					       comp_len);
					memcpy(outcurrpageaddr, incurrpageaddr,
					       chunk_size);
					comp_len = chunk_size;
					err = 0;
				}
				curr_comp_len += comp_len;
				currusdelta +=
					ktime_us_delta(finished, started);
				curr_len -= chunk_size;
				incurrpageaddr += chunk_size;
				outcurrpageaddr += chunk_size;
			}
			pr_err(PREFIX "compr %s(%d) in %ukB chunks took %lld us (%llu MB/s), compress ratio: %u.%02u\n",
			       run_id, compr_name, level, chunk_size >> 10,
			       currusdelta,
			       currusdelta ?
				(u64)in_len * 1000000 / currusdelta / 1048576 :
				0,
			       in_len / curr_comp_len,
			       (in_len % curr_comp_len) * 100 / curr_comp_len);
			chunk_size = chunk_size << 1;
			cond_resched();
		}
	}

	comp_len = in_len;
	started = ktime_get();
	err = crypto_comp_compress(cc, inpageaddr, in_len,
				   comppageaddr, &comp_len);
	finished = ktime_get();
	if (err || comp_len >= in_len) {
		/* If compress returns error, or if output len is greater than
		 * input len, it means it is not worth compressing.
		 * So just copy input into output.
		 */
		pr_err(PREFIX "cannot compress %d bytes, compressor %s,%d (out len %d), leave uncompressed\n",
		       run_id, in_len, compr_name, level, comp_len);
		memcpy(comppageaddr, inpageaddr, in_len);
		comp_len = in_len;
		err = 0;
	}
	usdelta = ktime_us_delta(finished, started);
	pr_err(PREFIX "compr %s(%d) in %ukB chunks took %lld us (%llu MB/s), compress ratio: %u.%02u\n",
	       run_id, compr_name, level, in_len >> 10,
	       usdelta, usdelta ? (u64)in_len * 1000000 / usdelta / 1048576 : 0,
	       in_len / comp_len, (in_len % comp_len) * 100 / comp_len);

	decomppageaddr = kmap(decomp_out_page);
	started = ktime_get();
	err = crypto_comp_decompress(cc, comppageaddr, comp_len,
				     decomppageaddr, &decomp_len);
	finished = ktime_get();
	if (err) {
		pr_err(PREFIX "ERROR cannot decompress %d bytes, compressor %s, error %d\n",
		       run_id, comp_len, compr_name, err);
		goto free;
	}
	if (decomp_len != in_len) {
		pr_err(PREFIX "ERROR decompressed len %d != initial len %d\n",
		       run_id, decomp_len, in_len);
		err = -1;
		goto free;
	}
	if (memcmp(inpageaddr, decomppageaddr, in_len)) {
		pr_err(PREFIX "ERROR decompressed different from initial\n",
		       run_id);
		err = -1;
	}
	usdelta = ktime_us_delta(finished, started);
	pr_err(PREFIX "decompr %s(%d) took %lld us (%llu MB/s)\n",
	       run_id, compr_name, level, usdelta,
	       usdelta ? (u64)comp_len * 1000000 / usdelta / 1048576 : 0);

free:
	if (cc)
		crypto_free_comp(cc);
	if (inpageaddr)
		kunmap(inpageaddr);
	if (comppageaddr)
		kunmap(comppageaddr);
	if (decomppageaddr)
		kunmap(decomppageaddr);
	if (comp_out_page)
		__free_pages(comp_out_page, order);
	if (decomp_out_page)
		__free_pages(decomp_out_page, order);
	return err;
}

/* compress and decompress, scomp variant */
static int test_acomp_compress_decompress(struct page *in_page,
					  unsigned int order,
					  char *compr_name, int level)
{
#ifdef HAVE_CRYPTO_INIT_WAIT
	struct page *comp_out_page = NULL, *decomp_out_page = NULL;
	unsigned int in_len = 1 << (PAGE_SHIFT + order);
	void *inpageaddr = NULL, *decomppageaddr = NULL;
	struct sg_table src_sgt, dst_sgt;
	unsigned int comp_len, decomp_len;
	struct crypto_acomp *ca = NULL;
	struct acomp_req *req = NULL;
	ktime_t started, finished;
	struct crypto_wait wait;
	struct scatterlist *s;
	unsigned long size;
	struct page *p;
	u64 usdelta;
	int i, err = -1;

	/* allocate 1 << order contiguous pages for compression output */
	comp_out_page = alloc_pages(GFP_KERNEL, order);
	if (!comp_out_page) {
		pr_err(PREFIX "ENOMEM cannot allocate comp_out_page\n", run_id);
		goto free;
	}
	/* allocate 1 << order contiguous pages for decompression output */
	decomp_out_page = alloc_pages(GFP_KERNEL, order);
	if (!decomp_out_page) {
		pr_err(PREFIX "ENOMEM cannot allocate decomp_out_page\n",
		       run_id);
		goto free;
	}

	ca = crypto_alloc_acomp(compr_name, 0, 0);
	if (IS_ERR(ca)) {
		pr_err(PREFIX
		       "ERROR cannot initialize compressor %s, error %ld\n",
		       run_id, compr_name, PTR_ERR(ca));
		ca = NULL;
		goto free;
	}

	if (level != -1)
		ll_crypto_acomp_set_level(ca, level);

	req = acomp_request_alloc(ca);
	if (!req) {
		pr_err(PREFIX
		       "ERROR request alloc failed for %s\n",
		       run_id, compr_name);
		goto free;
	}

	crypto_init_wait(&wait);
	err = sg_alloc_table(&src_sgt, 1 << order, GFP_KERNEL);
	if (err)
		goto free;
	p = in_page;
	for_each_sg(src_sgt.sgl, s, src_sgt.orig_nents, i)
		sg_set_page(s, p + i, PAGE_SIZE, 0);
	err = sg_alloc_table(&dst_sgt, 1 << order, GFP_KERNEL);
	if (err) {
		sg_free_table(&src_sgt);
		goto free;
	}
	p = comp_out_page;
	for_each_sg(dst_sgt.sgl, s, dst_sgt.orig_nents, i)
		sg_set_page(s, p + i, PAGE_SIZE, 0);

	acomp_request_set_params(req, src_sgt.sgl, dst_sgt.sgl, in_len, in_len);
	acomp_request_set_callback(req, CRYPTO_TFM_REQ_MAY_BACKLOG,
				   crypto_req_done, &wait);

	started = ktime_get();
	err = crypto_wait_req(crypto_acomp_compress(req), &wait);
	finished = ktime_get();
	sg_free_table(&src_sgt);
	sg_free_table(&dst_sgt);
	comp_len = req->dlen;
	if (err || comp_len >= in_len) {
		/* If compress returns error, or if output len is greater than
		 * input len, it means it is not worth compressing.
		 * So just copy input into output.
		 */
		pr_err(PREFIX "cannot compress %d bytes, compressor %s,%d (out len %d), leave uncompressed\n",
		       run_id, in_len, compr_name, level, comp_len);
		inpageaddr = kmap(in_page);
		decomppageaddr = kmap(comp_out_page);
		memcpy(decomppageaddr, inpageaddr, in_len);
		kunmap(inpageaddr);
		kunmap(decomppageaddr);
		comp_len = in_len;
		err = 0;
	}
	usdelta = ktime_us_delta(finished, started);
	pr_err(PREFIX "acompr %s(%d) of %ukB chunks took %lld us (%llu MB/s), compress ratio: %u.%02u\n",
	       run_id, compr_name, level, in_len >> 10,
	       usdelta, (u64)in_len * 1000000 / usdelta / 1048576,
	       in_len / comp_len, (in_len % comp_len) * 100 / comp_len);

	crypto_init_wait(&wait);
	err = sg_alloc_table(&src_sgt, 1 << order, GFP_KERNEL);
	if (err)
		goto free;
	p = comp_out_page;
	size = comp_len;
	for_each_sg(src_sgt.sgl, s, src_sgt.orig_nents, i) {
		sg_set_page(s, p + i, min_t(unsigned long, size, PAGE_SIZE), 0);
		if (size < PAGE_SIZE)
			break;
		size -= PAGE_SIZE;
	}
	err = sg_alloc_table(&dst_sgt, 1 << order, GFP_KERNEL);
	if (err) {
		sg_free_table(&src_sgt);
		goto free;
	}
	p = decomp_out_page;
	for_each_sg(dst_sgt.sgl, s, dst_sgt.orig_nents, i)
		sg_set_page(s, p + i, PAGE_SIZE, 0);

	acomp_request_set_params(req, src_sgt.sgl, dst_sgt.sgl,
				 comp_len, in_len);

	started = ktime_get();
	err = crypto_wait_req(crypto_acomp_decompress(req), &wait);
	finished = ktime_get();
	sg_free_table(&src_sgt);
	sg_free_table(&dst_sgt);
	decomp_len = req->dlen;
	if (err) {
		pr_err(PREFIX "ERROR cannot decompress %d bytes, compressor %s, error %d\n",
		       run_id, comp_len, compr_name, err);
		goto free;
	}
	if (decomp_len != in_len) {
		pr_err(PREFIX "ERROR decompressed len %d != initial len %d\n",
		       run_id, decomp_len, in_len);
		err = -1;
		goto free;
	}
	inpageaddr = kmap(in_page);
	decomppageaddr = kmap(decomp_out_page);
	if (memcmp(inpageaddr, decomppageaddr, in_len)) {
		pr_err(PREFIX "ERROR decompressed different from initial\n",
		       run_id);
		err = -1;
	}
	kunmap(inpageaddr);
	kunmap(decomppageaddr);
	usdelta = ktime_us_delta(finished, started);
	pr_err(PREFIX "adecompr %s(%d) took %lld us (%llu MB/s)\n",
	       run_id, compr_name, level, usdelta,
	       (u64)comp_len * 1000000 / usdelta / 1048576);

free:
	if (req)
		acomp_request_free(req);
	if (ca)
		crypto_free_acomp(ca);
	return err;
#else /* !HAVE_CRYPTO_INIT_WAIT */
	pr_err(PREFIX "SKIP test_acomp_compress_decompress(%s), not supported\n",
	       run_id, compr_name);
	return 0;
#endif /* HAVE_CRYPTO_INIT_WAIT */
}

static int order_from_len(unsigned int len)
{
	int order = 0;

	while (len > 1) {
		order++;
		len >>= 1;
	}

	return order - PAGE_SHIFT;
}

static int __init kcompr_init(void)
{
	/* Allocate 1 << 22 = 4MB for input data */
	unsigned int order = 22 - PAGE_SHIFT, order_eff;
	struct page *page = NULL;
	int idx = 0;
	int rc = 0;

	/* allocate 1 << order contiguous pages */
	page = alloc_pages(GFP_KERNEL, order);
	if (!page) {
		pr_err(PREFIX "ENOMEM cannot allocate pages\n", run_id);
		goto out;
	}

	/* initialize input buffers */
	if (input_file != NULL && input_file[0] != '\0') {
		/* write content of provided file into pages to compress */
		rc = fill_input_from_file(input_file, page,
					  1 << (PAGE_SHIFT + order));
		pr_err(PREFIX "*****\n", run_id);
		pr_err(PREFIX "(de)compression test on provided file %s\n",
		       run_id, input_file);
		pr_err(PREFIX "*****\n", run_id);
	} else {
		/* write binary test data into pages to compress */
		rc = fill_input_with_rand(page, 1 << (PAGE_SHIFT + order));
		pr_err(PREFIX "*****\n", run_id);
		pr_err(PREFIX "(de)compression test on random binary data\n",
		       run_id);
		pr_err(PREFIX "*****\n", run_id);
	}
	if (rc < 0) {
		pr_err(PREFIX "cannot fill in input buffer, ret %d\n",
		       run_id, rc);
		goto out;
	}

	order_eff = order_from_len(rc);

	/* proceed to compression/decompression, for each algorithm in the list,
	 * for both generic and scomp variants
	 */
	for (idx = 0; idx < ARRAY_SIZE(compr_algs); idx++) {
		rc = test_comp_compress_decompress(page, order_eff,
						   compr_algs[idx].cd_name,
						   compr_algs[idx].cd_level);
		pr_err(PREFIX "test_comp_compress_decompress(%s,%d) ret %d\n",
		       run_id, compr_algs[idx].cd_name,
		       compr_algs[idx].cd_level, rc);
		if (rc)
			goto out;

		/* only compress first 1 << 17 = 128 kB,
		 * max len accepted by scomp variants
		 */
		rc = test_acomp_compress_decompress(page,
						    min((int)order_eff,
							17 - PAGE_SHIFT),
						    compr_algs[idx].cd_name,
						    compr_algs[idx].cd_level);
		pr_err(PREFIX "test_acomp_compress_decompress(%s,%d) ret %d\n",
		       run_id, compr_algs[idx].cd_name,
		       compr_algs[idx].cd_level, rc);
		if (rc)
			goto out;
	}

	pr_err(PREFIX "SUCCESS\n", run_id);

out:
	if (page)
		__free_pages(page, order);
	/* Don't load. */
	return -EINVAL;
}

static void __exit kcompr_exit(void)
{
}

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("compression/decompression test module");
MODULE_VERSION(LUSTRE_VERSION_STRING);

module_init(kcompr_init);
module_exit(kcompr_exit);
