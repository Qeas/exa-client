/* GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */

/*
 * Copyright (c) 2023, DataDirect Networks Inc, all rights reserved.
 * Author: Artem Blagodarenko <ablagodarenko@whamcloud.com>
 */
#ifndef _OFD_COMPRESS_H
#define _OFD_COMPRESS_H

#define DEBUG_SUBSYSTEM S_FILTER

#include <lustre_debug.h>
#include <linux/falloc.h>
#include "ofd_internal.h"

int decompress_rnb(struct obd_export *exp, struct lu_fid *fid,
		   struct niobuf_local *lnbs, int lnb_npages,
		   __u64 rnb_start, __u64 rnb_end, int *lnb_offset,
		   void **bounce_src, void **bounce_dst,
		   enum ll_compr_type type, int lvl, int chunk_size,
		   bool write);

#endif /* _OFD_COMPRESS_H */
