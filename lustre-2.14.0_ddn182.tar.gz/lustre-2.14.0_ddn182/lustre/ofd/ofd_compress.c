/* GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */

/*
 * Copyright (c) 2023, DataDirect Networks Inc, all rights reserved.
 * Author: Artem Blagodarenko <ablagodarenko@whamcloud.com>
 */

#define DEBUG_SUBSYSTEM S_FILTER

#include <lustre_debug.h>
#include <linux/falloc.h>
#include "ofd_internal.h"
#include "ofd_compress.h"
#include <lustre_compr.h>
#include <lustre_sec.h>

/*
 * each chunk in a compressed file we work with is represented
 * by struct csdc_chunk.
 *
 * READ:
 * - map niobufs to chunks
 * - read chunks
 * - if read is partial (niobufs don't cover whole chunks), then
 *   uncompress into temporary buffers
 * - create lnbs for OST, mapping them to:
 *    - osd pages if chunk is not compressed or read chunk is full
 *    - temporary buffers otherwise (a part to be returned)
 * - let OST do bulk to the just returned lnbs
 * - release all lnbs, chunks, etc
 *
 * WRITE:
 * - map niobufs to chunks
 * - get disk lnbs for each chunk from OSD
 * - if chunk to writte is not full, then
 *   - read the whole chunk
 *   - uncompress into a temporary buffer (if needed)
 * - create lnbs for OST, mapping them to:
 *    - osd pages if existing chunk is not compressed or new chunk is compressed
 *    - temporary buffers otherwise (a part to be written)
 * - let OST do bulk to the just created lnbs
 * - copy data from temporary buffers to osd pages (if needed)
 * - write all disk lnbs
 * - release all lnbs, chunks, etc
 *
 * TRUNCATE:
 *  - convert compressed chunk into uncompressed like it's a write
 *  - do regular truncate
 *
 *
 * TODO:
 *  - (question) Clear uptodate on pagecache if bulk fail
 *  - (optional) Stats
 *    - full vs partial chunks
 *    - CPU spent for decompression
 *    - cache hits for RMW (can work with ldiskfs at least)
 *    - number of calls to dt_write_prep() per OST_WRITE
 *  - (optional) atomicity of big partial chunk overwrite
 *    a compressed chunk can get broken by incomplete multi-transaction write?
 *  - Tests
 *    - error handling
 *    - big chunks
 *  - lseek / fallocate support
 *  - Chunk cache
 *    - cache uncompressed data
 *    - radix tree of chunks
 *    - don't release temporary pages in ofd_uncompress_chunk()
 *    - invalidate if compressed chunk overwrites
 *  - Punch unused blocks at overwrite
 */

#define COMPRESSION_DEBUG	1
#ifdef COMPRESSION_DEBUG
void save_niobufs(const struct lu_env *env, struct niobuf_remote *rnb, int nr)
{
	struct ofd_thread_info *info = ofd_info(env);

	if (nr > info->fti_rnb_max) {
		if (info->fti_rnb) {
			OBD_FREE(info->fti_rnb, sizeof(*rnb) * info->fti_rnb_max);
			info->fti_rnb_max = 0;
		}
		info->fti_rnb_max = nr * 2;
		OBD_ALLOC(info->fti_rnb, sizeof(*rnb) * info->fti_rnb_max);
		if (info->fti_rnb == NULL)
			return;
	}

	info->fti_rnb_nr = nr;
	memcpy(info->fti_rnb, rnb, sizeof(*rnb) * info->fti_rnb_nr);
}

void print_compr_structures(const struct lu_env *env)
{
	struct ofd_thread_info *info = ofd_info(env);
	struct niobuf_remote *rnb = info->fti_rnb;
	struct csdc_chunk *chb = info->fti_chunk_bufs.lb_buf;
	int chn_nr, lnb_nr = 0;
	int i;

	CDEBUG(D_SEC, "%d niobufs:\n", info->fti_rnb_nr);
	for (i = 0; i < info->fti_rnb_nr; i++) {
		CDEBUG(D_SEC, "%u @ %llu %s\n",
			rnb[i].rnb_len, rnb[i].rnb_offset,
			rnb[i].rnb_flags & OBD_BRW_COMPRESSED ? "compressed" : "");
	}
	chn_nr = info->fti_chunk_nr;
	CDEBUG(D_SEC, "%d chunks:\n", chn_nr);
	for (i = 0; i < chn_nr; i++) {
		lnb_nr += chb[i].cch_nr;
		CDEBUG(D_SEC, "%llu/%u with %u @ %u data%s %d lnbs %s\n",
				chb[i].cch_offset, chb[i].cch_chunksize,
				chb[i].cch_len, chb[i].cch_start,
				chb[i].cch_compressed ? "  compressed" : "",
				chb[i].cch_nr,
				chb[i].cch_temp_pages ? "(unpacked)" : "");
	}
	CDEBUG(D_SEC, "%d disk lnbs:\n", lnb_nr);
	for (i = 0; i < lnb_nr; i++) {
		CDEBUG(D_SEC, "%u @ %u / %llu rc %d page %p %s%s%s\n",
			info->fti_lnb_bufs[i].lnb_len,
			info->fti_lnb_bufs[i].lnb_page_offset,
			info->fti_lnb_bufs[i].lnb_file_offset,
			info->fti_lnb_bufs[i].lnb_rc,
			info->fti_lnb_bufs[i].lnb_page,
			info->fti_lnb_bufs[i].lnb_page->mapping ? "C" : "",
			PageUptodate(info->fti_lnb_bufs[i].lnb_page) ? "U" : "",
			PageMappedToDisk(info->fti_lnb_bufs[i].lnb_page) ? "M" : "");
	}
}

#else
#define save_niobufs(env, rnb, nr)
#define print_compr_structures(env)
#endif

int ofd_prepare_lnb_bufs(const struct lu_env *env, struct csdc_chunk *chb, int nr)
{
	struct ofd_thread_info *info = ofd_info(env);
	int max;

	max = (chb->cch_chunksize / PAGE_SIZE) * nr;
	if (likely(max <= info->fti_lnb_max))
		return 0;

	if (info->fti_lnb_bufs) {
		OBD_FREE(info->fti_lnb_bufs,
			  sizeof(struct niobuf_local) * info->fti_lnb_max);
		info->fti_lnb_bufs = NULL;
	}
	if (info->fti_lnb2_bufs) {
		OBD_FREE(info->fti_lnb2_bufs,
			sizeof(struct niobuf_local) * info->fti_lnb_max);
		info->fti_lnb2_bufs = NULL;
	}
	info->fti_lnb_max = 0;

	/* will be freed in ofd_key_fini() */
	OBD_ALLOC(info->fti_lnb_bufs, sizeof(struct niobuf_local) * max);
	if (info->fti_lnb_bufs == NULL)
		return -ENOMEM;
	OBD_ALLOC(info->fti_lnb2_bufs, sizeof(struct niobuf_local) * max);
	if (info->fti_lnb2_bufs == NULL) {
		OBD_FREE(info->fti_lnb_bufs,
			sizeof(struct niobuf_local) * max);
		info->fti_lnb_bufs = NULL;
		return -ENOMEM;
	}
	info->fti_lnb_max = max;

	return 0;
}

void ofd_range_lock_chunks(const struct lu_env *env, struct ofd_object *fo,
			   struct csdc_chunk *chb, int nr)
{
	int i;

	for (i = 0; i < nr; i++) {
		range_lock_init(&chb[i].cch_lock, chb[i].cch_offset,
				chb[i].cch_offset + chb[i].cch_chunksize - 1);
		range_lock(&fo->ofo_write_tree, &chb[i].cch_lock);
		chb[i].cch_locked = 1;
	}
}

static inline __u64 chunk_align(__u64 offset, __u32 size)
{
	return (offset / size) * size;
}

inline void ofd_init_chbuf(struct csdc_chunk *chb, __u32 chunksize,
			   __u64 offset, __u32 start, __u32 len, __u32 end,
			   __u32 flags)
{
	memset(chb, 0, sizeof(*chb));
	chb->cch_chunksize = chunksize;
	chb->cch_offset = chunk_align(offset, chunksize);
	chb->cch_start = start;
	chb->cch_len = len;
	chb->cch_end = end;
	chb->cch_flags = flags;
}

static int ofd_prepare_bufs_compr(struct lu_buf *lb, int nr)
{
	if (lb->lb_len >= (nr * sizeof(struct csdc_chunk)))
		return 0;

	lu_buf_realloc(lb, nr * sizeof(struct csdc_chunk));
	if (lb->lb_buf == NULL)
		return -ENOMEM;
	return 0;
}

/*
 * This function initialize a set of "chunks" from remote bufs passed in.
 * The chunks will be units of IO later.
 */
int ofd_map_niobuf_to_chunks(const struct lu_env *env,
			     struct niobuf_remote *rnb, int nr,
			     struct csdc_chunk **retchb, int *retmax,
			     int chunksize, bool write)
{
	struct ofd_thread_info *info = ofd_info(env);
	struct csdc_chunk *chb;
	int cidx; /* current chunk index */
	int i, max = 16;

	save_niobufs(env, rnb, nr);

repeat:
	max = max * 2;
	if (ofd_prepare_bufs_compr(&info->fti_chunk_bufs, max))
		return -ENOMEM;
	max = info->fti_chunk_bufs.lb_len / sizeof(*chb);
	chb = info->fti_chunk_bufs.lb_buf;
	chb[0].cch_len = 0;
	cidx = 0;

	for (i = 0; i < nr; i++) {
		__u32 len, chlen, choff, left;
		__u64 off, end;

		/* handle this remote buffer */
		off = rnb[i].rnb_offset;
		len = rnb[i].rnb_len;
		end = off + len;

		if ((rnb[i].rnb_flags & OBD_BRW_COMPRESSED) && write) {
			/* compressed niobuf covers a full chunk always */
			if (unlikely(off & (chunksize - 1))) {
				CERROR("niobuf @%llu isn't aliged\n", off);
				return -EINVAL;
			}

			LASSERT(chb[cidx].cch_len == 0 || chb[cidx].cch_offset != off);

			for (; off < end; off += chunksize) {
				CDEBUG(D_SEC, "cidx: %i, off: %llu, len: %u\n",
				       cidx, off, len);
				left = end - off;
				if (left > chunksize)
					left = chunksize;

				if (chb[cidx].cch_len)
					cidx++;
				if (cidx >= max)
					goto repeat;
				ofd_init_chbuf(chb + cidx, chunksize, off, 0,
					       left, left, rnb[i].rnb_flags);
				chb[cidx].cch_compressed = 1;
				if (++cidx >= max)
					goto repeat;
				chb[cidx].cch_len = 0;
			}
			continue;
		}

		/* one buffer can cross number of chunks
		 * generate and markup chunks from this buffer */
		while (len > 0) {
			/* part of chunk covered by this niobuf */
			choff = off & (chunksize - 1);
			chlen = len;
			if (choff + chlen > chunksize)
				chlen = chunksize - choff;

			if (chb[cidx].cch_len == 0) {
				/* the very first bit in this chunk */
				ofd_init_chbuf(chb + cidx, chunksize, off,
					       choff, chlen, choff + chlen,
					       rnb[i].rnb_flags);
			} else if (chb[cidx].cch_offset == chunk_align(off, chunksize)) {
				/* still in the same chunk */
				if (chb[cidx].cch_start + chb[cidx].cch_len == choff) {
					chb[cidx].cch_len += chlen;
				} else {
					/* there is a gap in chunk coverage */
					LASSERT(choff >= chb[cidx].cch_start + chb[cidx].cch_len);
					chb[cidx].cch_len += chlen;
				}
				if (choff + chlen > chb[cidx].cch_end)
					chb[cidx].cch_end = choff + chlen;
			} else {
				/* we step to the next chunk */
				if (++cidx >= max)
					goto repeat;
				ofd_init_chbuf(chb + cidx, chunksize, off, choff,
					       chlen, choff + chlen,
					       rnb[i].rnb_flags);
			}

			/* go for next part of this buffer */
			off += chlen;
			len -= chlen;
		}
	}
	if (chb[cidx].cch_len != 0)
		cidx++;
	info->fti_chunk_nr = *retmax = cidx;
	*retchb = chb;

	/*
	 * XXX: add a runtime set of tests for chunks:
	 * overlapping, coverage of rnbs, etc
	 */

	return 0;
}

void ofd_release_chunk_lnb(const struct lu_env *env, struct ofd_object *fo,
			   struct csdc_chunk *chb, int nr)
{
	int i;

	for (i = 0; i < nr; i++) {
		if (chb[i].cch_lnb == NULL)
			continue;
		dt_bufs_put(env, ofd_object_child(fo),
			    chb[i].cch_lnb, chb[i].cch_nr);
		chb[i].cch_lnb = NULL;
	}
}

void ofd_release_temp_buffers(const struct lu_env *env, struct ofd_object *fo,
			      struct csdc_chunk *chb, int nr)
{
	int i;

	if (fo->ofo_compressed == 0)
		return;

	for (i = 0; i < nr; i++) {
		if (chb[i].cch_locked) {
			range_unlock(&fo->ofo_write_tree, &chb[i].cch_lock);
			chb[i].cch_locked = 0;
		}
		if (chb[i].cch_temp_pages == NULL)
			continue;
		if (chb[i].cch_temp_pages[0])
			sptlrpc_pool_put_pages_array(chb[i].cch_temp_pages,
						     chb[i].cch_temp_nr);
		OBD_FREE(chb[i].cch_temp_pages,
			 sizeof(struct page*) * chb[i].cch_temp_nr);
		chb[i].cch_temp_pages = NULL;
	}
}

/*
 * Each chunk has a set of lnbs associated. The function tries to find an lnb
 * for the given offset. To speed up the process the function saves current
 * position (chunk number and lnb number in this chunk) to be used once called
 * again.
 */
static struct niobuf_local *find_lnb(unsigned long offset, struct csdc_chunk *chb,
				     int *cidx, int max, int *lidx)
{
	int j;

	while (*cidx < max) {
		for (j = *lidx; j < chb[*cidx].cch_nr; j++) {
			struct niobuf_local *lnb = chb[*cidx].cch_lnb + j;
			if (offset >= lnb->lnb_file_offset &&
			    offset < lnb->lnb_file_offset + lnb->lnb_len) {
				*lidx = j;
				return lnb;
			}
		}
		(*cidx)++;
		*lidx = 0;
	}
	return NULL;
}

/*
 * The function fills @lnb array using lnbs/pages described in chunks @chb.
 * notice this array has nothing to do with lnbs provided by OSD.
 */
void ofd_generate_lnbs_from_chunks(const struct lu_env *env,
				   struct niobuf_remote *rnb, int rnbnr,
				   struct csdc_chunk *chb, int chnr,
				   struct niobuf_local *lnb, int *lnbnr,
				   bool write)
{
	int saved_chunk = 0; /* current chunk index for fast search */
	int saved_lnb = 0; /* current lnb index for fast search */
	int li = 0; /* lnb index */
	int ri; /* rnb index */

	for (ri = 0; ri < rnbnr; ri++) {
		__u64 off = rnb[ri].rnb_offset;
		__u32 len = rnb[ri].rnb_len;

		while (len > 0) {
			struct niobuf_local *f;

			f = find_lnb(off, chb, &saved_chunk, chnr, &saved_lnb);
			if (f == NULL)
				print_compr_structures(env);
			LASSERTF(f != NULL, "can't find lnb for %llu\n", off);

			/* make a new lnb pointing to the data */
			lnb[li].lnb_file_offset = f->lnb_file_offset;
			lnb[li].lnb_page_offset = off - f->lnb_file_offset;

			lnb[li].lnb_len = f->lnb_len - lnb[li].lnb_page_offset;
			if (chb[saved_chunk].cch_temp_pages) {
				lnb[li].lnb_page =
					chb[saved_chunk].cch_temp_pages[saved_lnb];
				if (!write)
					lnb[li].lnb_guard_disk = 0;
			} else {
				lnb[li].lnb_page = f->lnb_page;
				if (!write) {
					lnb[li].lnb_guard_disk = f->lnb_guard_disk;
					if (f->lnb_guard_disk)
						memcpy(lnb[li].lnb_guards,
						       f->lnb_guards,
						       sizeof(lnb[li].lnb_guards));
				}
			}
			if (write)
				lnb[li].lnb_guard_rpc = 0;

			if (lnb[li].lnb_len > len)
				lnb[li].lnb_len = len;
			lnb[li].lnb_rc = f->lnb_rc;
			lnb[li].lnb_flags = f->lnb_flags;

			/* go for next bit */
			len -= lnb[li].lnb_len;
			off += lnb[li].lnb_len;
			li++;
		}
	}
	*lnbnr = li;
}

/*
 * the function prepares given chunks @chb for the read path:
 *  - asks OSD for appropriate lnbs
 *  - reads lnbs from the storage
 *  - decompress partial chunks
 *
 * XXX: unify with _write()
 */
static int ofd_map_chunks_to_lnb_read(const struct lu_env *env,
				      struct obd_device *obd,
				      struct ofd_object *fo,
				      struct csdc_chunk *chb, int nr)
{
	struct ofd_thread_info *info = ofd_info(env);
	struct tgt_session_info *tsi = tgt_ses_info(env);
	struct obd_device_target *target = &tsi->tsi_exp->exp_obd->u.obt;
	__u64 end, bytes_disk, bytes_user, bytes_decompressed;
	int i, rc, maxlnb, used = 0, chunk_decompressed;
	struct ll_compr_hdr *llch = &info->fti_llch;
	struct lu_attr *la = &info->fti_attr2;
	struct niobuf_local *lnb;

	if (ofd_prepare_lnb_bufs(env, chb, nr))
		RETURN(-ENOMEM);
	maxlnb = info->fti_lnb_max;
	lnb = info->fti_lnb_bufs;

	/* XXX: no need to do this multiple times */
	rc = dt_attr_get(env, ofd_object_child(fo), la);
	if (rc)
		RETURN(rc);
	LASSERT(la->la_valid & LA_SIZE);

	bytes_disk = bytes_user = bytes_decompressed = chunk_decompressed = 0;

	for (i = 0; i < nr; i++) {
		int pages;

		chb[i].cch_lnb = lnb;
		LASSERT(chb[i].cch_compressed == 0);

		/* need to read partial chunk: upto old or new size within a chunk */
		end = max_t(__u64, la->la_size,
			    chb[i].cch_offset + chb[i].cch_end);
		if (end > chb[i].cch_offset + chb[i].cch_chunksize)
			end = chb[i].cch_offset + chb[i].cch_chunksize;
		pages = (end - chb[i].cch_offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
		if (pages + maxlnb > PTLRPC_MAX_BRW_PAGES) {
			struct tgt_session_info *tsi = tgt_ses_info(env);

			rc = -EOVERFLOW;
			DEBUG_REQ(D_ERROR, tgt_ses_req(tsi),
				  "%s: too large request %d > limit %u for compressed IO on "DFID": rc = %d\n",
				  obd->obd_name, pages + maxlnb,
				  PTLRPC_MAX_BRW_PAGES,
				  PFID(lu_object_fid(&fo->ofo_obj.do_lu)), rc);
			GOTO(err, rc);
		}
		rc = dt_bufs_get(env, ofd_object_child(fo),
				lnb, chb[i].cch_offset,
				end - chb[i].cch_offset,
				maxlnb, DT_BUFS_TYPE_READ);
		if (rc < 0) {
			CERROR("can't get bufs: rc=%d\n", rc);
			GOTO(err, rc);
		}
		maxlnb -= rc;
		lnb += rc;
		used += rc;
		chb[i].cch_nr = rc;
	}

	rc = dt_read_prep(env, ofd_object_child(fo), info->fti_lnb_bufs, used);
	if (rc) {
		CERROR("can't prepare buffers: rc=%d\n", rc);
		GOTO(err, rc);
	}

	for (i = 0; i < nr; i++) {

		if (chb[i].cch_lnb[0].lnb_rc < sizeof(struct ll_compr_hdr)) {
			/* XXX: probably this can be a broken compressed chunk? */
			continue;
		}

		/* if uncompressed - return right as is */
		if (!is_chunk_start(chb[i].cch_lnb[0].lnb_page, llch, &rc)) {
			bytes_user += PAGE_ALIGN(chb[i].cch_len);
			bytes_disk += PAGE_ALIGN(chb[i].cch_len);
			continue;
		}
		bytes_user += PAGE_ALIGN(llch->llch_uncompr_size);
		bytes_disk += PAGE_ALIGN(llch->llch_compr_size +
					 llch->llch_header_size);

		/* the chunk is compressed and aligned */
		if (chb[i].cch_start == 0 && chb[i].cch_len == chb[i].cch_chunksize) {
			/* we're asked for the whole one */
			/* save compressed size so in the future we can form
			 * short set of lnbs, currently the network doesn't
			 * suppor this. see LU-16897 */
			chb[i].cch_compressed_size =
				llch->llch_compr_size + llch->llch_header_size;
			continue;
		}

		/* the client asked for a part of the chuck,
		 * let's produce some heat:
		 * - have another set of buffers for a whole chunk
		 * - decompress just read lnbs into this new buffer */
		rc = ofd_decompress_chunk(env, fo, &chb[i], llch);
		if (rc)
			GOTO(err, rc);

		bytes_decompressed += llch->llch_uncompr_size;
		chunk_decompressed++;
	}

	lprocfs_counter_add(target->obt_compr_stats,
			    LPROC_OFD_COMPR_BYTE_READ_DISK, bytes_disk);
	lprocfs_counter_add(target->obt_compr_stats,
			    LPROC_OFD_COMPR_CHUNK_READ_DISK, nr);
	lprocfs_counter_add(target->obt_compr_stats,
			    LPROC_OFD_COMPR_BYTE_READ_USER,
			    bytes_user);
	if (chunk_decompressed) {
		lprocfs_counter_add(target->obt_compr_stats,
				    LPROC_OFD_COMPR_CHUNK_READ_DECOMPRESSED,
				    chunk_decompressed);
		lprocfs_counter_add(target->obt_compr_stats,
				    LPROC_OFD_COMPR_BYTE_READ_DECOMPRESSED,
				    bytes_decompressed);
	}

err:
	if (rc) {
		ofd_release_chunk_lnb(env, fo, chb, nr);
		ofd_release_temp_buffers(env, fo, chb, nr);
	}
	RETURN(rc);
}

/*
 * this is a part of obd_preprw() path for compressed files:
 *  - create chunks from the remote niobufs
 *  - locks data covered by full chunks to avoid access to same chunks
 *  - do IO to fill chunks with actual data
 *  - decompress if needed (partial chunk access)
 *  - generate output lnbs for data requested (will be used to make bulks)
 */
int ofd_preprw_read_compr(const struct lu_env *env,
			  struct obd_export *exp, struct ofd_device *ofd,
			  struct ofd_object *fo, struct lu_attr *la,
			  struct obdo *oa, int niocount,
			  struct niobuf_remote *rnb, int *nr_local,
			  struct niobuf_local *lnb)
{
	struct ost_layout_compr *olc = &oa->o_layout_compr;
	struct obd_device *obd = ofd_obd(ofd);
	struct csdc_chunk *chb;
	int chunk_bits, chnr, rc;
	ENTRY;

	chunk_bits = olc->ol_compr_chunk_log_bits + COMPR_CHUNK_MIN_BITS;
	rc = ofd_map_niobuf_to_chunks(env, rnb, niocount, &chb,
				      &chnr, 1 << chunk_bits, false);
	if (rc)
		RETURN(rc);
	ofd_range_lock_chunks(env, fo, chb, chnr);

	rc = ofd_map_chunks_to_lnb_read(env, obd, fo, chb, chnr);
	if (rc)
		GOTO(out, rc);

	ofd_generate_lnbs_from_chunks(env, rnb, niocount, chb,
				      chnr, lnb, nr_local, false);

out:
	if (rc)
		ofd_release_temp_buffers(env, fo, chb, chnr);

	RETURN(rc);
}

/*
 * just provides regular ofd ofd_commitrw_read() with on-disk lnbs
 * so they will be released properly.
 */
int ofd_commitrw_read_compr(const struct lu_env *env, struct ofd_object *fo,
			    struct niobuf_local **lnb, int *nr)
{
	struct ofd_thread_info *info = ofd_info(env);
	struct csdc_chunk *chb = info->fti_chunk_bufs.lb_buf;
	int i, npages = 0;

	LASSERT(chb);
	LASSERT(info->fti_chunk_nr > 0);
	for (i = 0; i < info->fti_chunk_nr; i++)
		npages += chb[i].cch_nr;
	*lnb = info->fti_lnb_bufs;
	*nr = npages;

	RETURN(0);
}

/*
 * the function prepare given chunks @chb for the write path:
 *  - asks OSD for appropriate lnbs
 *  - reads lnbs from the storage (if new data don't fill whole chunk)
 *  - decompress partial chunks
 *
 * XXX: unify with _read()
 */
int ofd_map_chunks_to_lnb_write(const struct lu_env *env,
				struct obd_device *obd, struct ofd_object *fo,
				struct csdc_chunk *chb, int nr,
				enum dt_bufs_type dbt)
{
	struct ofd_thread_info *info = ofd_info(env);
	struct lu_attr *la = &info->fti_attr2;
	struct ll_compr_hdr *llch = &info->fti_llch;
	struct niobuf_local *lnb;
	int i, k, rc, maxlnb;
	bool rmw;
	__u64 end;

	if (ofd_prepare_lnb_bufs(env, chb, nr))
		RETURN(-ENOMEM);
	maxlnb = info->fti_lnb_max;
	lnb = info->fti_lnb_bufs;

	dbt |= DT_BUFS_TYPE_WRITE | DT_BUFS_TYPE_COMPRESSION;

	/* XXX: no need to do this multiple times */
	rc = dt_attr_get(env, ofd_object_child(fo), la);
	if (rc)
		RETURN(rc);
	LASSERT(la->la_valid & LA_SIZE);

	for (i = 0; i < nr; i++) {
		int pages;

		chb[i].cch_lnb = lnb;
		rmw = true;

		/* need to read partial chunk: upto old or new
		 * size within a chunk */
		end = max_t(__u64, la->la_size,
			    chb[i].cch_offset + chb[i].cch_end);
		if (end > chb[i].cch_offset + chb[i].cch_chunksize)
			end = chb[i].cch_offset + chb[i].cch_chunksize;
		/* but full chunk is the full chunk */
		if (chb[i].cch_compressed)
			end = chb[i].cch_offset + chb[i].cch_len;

		pages = (end - chb[i].cch_offset + PAGE_SIZE - 1) >> PAGE_SHIFT;
		if (pages + maxlnb > PTLRPC_MAX_BRW_PAGES) {
			struct tgt_session_info *tsi = tgt_ses_info(env);

			rc = -EOVERFLOW;
			DEBUG_REQ(D_ERROR, tgt_ses_req(tsi),
				  "%s: too large request %d > limit %u for compressed IO on "DFID": rc = %d\n",
				  obd->obd_name, pages + maxlnb,
				  PTLRPC_MAX_BRW_PAGES,
				  PFID(lu_object_fid(&fo->ofo_obj.do_lu)), rc);
			GOTO(err, rc);
		}
		rc = dt_bufs_get(env, ofd_object_child(fo), lnb,
				 chb[i].cch_offset, end - chb[i].cch_offset,
				 maxlnb, dbt);
		LASSERT(rc != 0);
		if (rc < 0) {
			CERROR("%s: failed getting %u/%u bufs for compressed IO on "DFID": rc = %d\n",
			       obd->obd_name, i, nr,
			       PFID(lu_object_fid(&fo->ofo_obj.do_lu)), rc);
			GOTO(err, rc);
		}
		for (k = 0; k < rc; k++) {
			lnb[k].lnb_flags = chb[i].cch_flags;
			lnb[k].lnb_flags &= ~OBD_BRW_LOCALS;
			if (!(chb[i].cch_flags & OBD_BRW_GRANTED))
				lnb[k].lnb_rc = -ENOSPC;
		}
		maxlnb -= rc;
		lnb += rc;
		chb[i].cch_nr = rc;

		/*
		 * If full chunk (or compressed by client) is being written,
		 * then we don't need to read-modify-write, we can just
		 * overwrite with data we get from the client.
		 */
		if (chb[i].cch_compressed ||
		    (chb[i].cch_len == chb[i].cch_chunksize))
			rmw = false;

		if (rmw && chb[i].cch_start == 0 &&
		    chb[i].cch_offset + chb[i].cch_len >= la->la_size &&
		    chb[i].cch_offset <= la->la_size)
			rmw = false;

		/* XXX: optimize case when we modify few chunks and
		 * better to have one call to dt_write_prep() doing one IO
		 * submission instead of series of serialized calls */
		rc = dt_write_prep(env, ofd_object_child(fo),
				   chb[i].cch_lnb, chb[i].cch_nr, rmw);
		if (rc)
			GOTO(err, rc);

		/* buffers after EOF are supposed to be zero filled */

		if (!rmw)
			continue;

		/* if uncompressed - return right away */
		if (!is_chunk_start(chb[i].cch_lnb[0].lnb_page, llch, &rc))
			continue;

		/* if the write replaces all raw data - no need to decompress */
		if (chb[i].cch_start == 0 &&
		    chb[i].cch_len >= llch->llch_uncompr_size)
			continue;

		/* compressed:
		 * - have another set of buffers for a whole chunk
		 * - decompress just read lnbs into this new buffer */
		rc = ofd_decompress_chunk(env, fo, &chb[i], llch);
		if (rc)
			GOTO(err, rc);
	}
	rc = 0;

err:
	if (rc) {
		ofd_release_chunk_lnb(env, fo, chb, nr);
		ofd_release_temp_buffers(env, fo, chb, nr);
	}
	RETURN(rc);
}

int ofd_preprw_write_compr(const struct lu_env *env, struct obd_export *exp,
			   struct ofd_device *ofd, struct ofd_object *fo,
			   struct lu_attr *la, struct obdo *oa, int objcount,
			   struct obd_ioobj *obj, struct niobuf_remote *rnb,
			   int *nr_local, struct niobuf_local *lnb)
{
	struct ost_layout_compr *olc = &oa->o_layout_compr;
	enum dt_bufs_type dbt = 0;
	struct csdc_chunk *chb;
	int chunk_bits, chnr, rc;
	ENTRY;

	chunk_bits = olc->ol_compr_chunk_log_bits + COMPR_CHUNK_MIN_BITS;
	rc = ofd_map_niobuf_to_chunks(env, rnb, obj->ioo_bufcnt, &chb,
				      &chnr, 1 << chunk_bits, true);
	if (rc)
		RETURN(rc);
	ofd_range_lock_chunks(env, fo, chb, chnr);

	ofd_read_lock(env, fo);
	if (!ofd_object_exists(fo)) {
		CERROR("%s: BRW to missing obj "DOSTID": rc = -ENOENT\n",
		       exp->exp_obd->obd_name, POSTID(&obj->ioo_oid));
		GOTO(out, rc = -ENOENT);
	}

	if (ptlrpc_connection_is_local(exp->exp_connection))
		dbt |= DT_BUFS_TYPE_LOCAL;
	rc = ofd_map_chunks_to_lnb_write(env, exp->exp_obd, fo, chb, chnr,
					 dbt);
	if (rc)
		GOTO(out, rc);

	ofd_generate_lnbs_from_chunks(env, rnb, obj->ioo_bufcnt,
				      chb, chnr, lnb, nr_local, true);

out:
	ofd_read_unlock(env, fo);

	if (rc)
		ofd_release_temp_buffers(env, fo, chb, chnr);

	RETURN(rc);
}

static int ofd_grab_lnbs(struct csdc_chunk *chb, int chnr,
			 struct niobuf_local *src, int nr,
			 struct niobuf_local *dst, int max)

{
	int i, j, k, npages;

	for (i = 0, k = 0, npages = 0; i < chnr; i++, chb++) {
		struct niobuf_local *lnb = chb->cch_lnb;
		if (chb->cch_temp_pages) {
			/* need to write full uncompressed page */
			memcpy(dst, lnb, sizeof(*lnb) * chb->cch_nr);
			dst += chb->cch_nr;
			npages += chb->cch_nr;
			continue;
		}

		for (; k < nr; k++) {
			if (src[k].lnb_file_offset < chb->cch_offset)
				continue;
			if (src[k].lnb_file_offset >=
			    chb->cch_offset + chb->cch_chunksize)
				break;

			/* don't write blocks after compressed size,
			 * important for aarch */
			if (chb->cch_compressed_size && src[k].lnb_file_offset >=
			    chb->cch_offset + chb->cch_compressed_size)
				break;

			j = (src[k].lnb_file_offset - chb->cch_offset) >> PAGE_SHIFT;
			LASSERT(src[k].lnb_file_offset == lnb[j].lnb_file_offset);

			LASSERT(npages < max);
			npages++;

			*dst = lnb[j];
			dst++;
		}
	}

	return npages;
}

int ofd_commitrw_write_compr(const struct lu_env *env, struct ofd_object *fo,
			     struct niobuf_local **lnb, int *nr,
			     struct lu_attr *la)
{
	struct tgt_session_info *tsi = tgt_ses_info(env);
	struct obd_device_target *target = &tsi->tsi_exp->exp_obd->u.obt;
	struct ofd_thread_info *info = ofd_info(env);
	struct csdc_chunk *chb = info->fti_chunk_bufs.lb_buf;
	struct ll_compr_hdr *llch = &info->fti_llch;
	struct lu_attr *la2 = &info->fti_attr2;
	__u64 user_bytes = 0, bytes_rmw = 0, bytes_user_rmw = 0;
	int chunks_compressed = 0, chunks_rmw = 0;
	int i, j, rc, npages = 0;

	rc = dt_attr_get(env, ofd_object_child(fo), la2);
	if (unlikely(rc))
		GOTO(out, rc);
	for (i = 0; i < info->fti_chunk_nr; i++) {
		if (chb[i].cch_compressed == 0) {
			user_bytes += chb[i].cch_len;
			continue;
		}
		if (!is_chunk_start(chb[i].cch_lnb[0].lnb_page, llch, &rc)) {
			CERROR("%s: chunk is not compressed\n",
			       info->fti_exp->exp_obd->obd_name);
			GOTO(out, rc = -EINVAL);
		}

		/* save how much we really need to write */
		chb[i].cch_compressed_size = PAGE_ALIGN(llch->llch_compr_size +
			llch->llch_header_size);

		user_bytes += llch->llch_uncompr_size;
		chunks_compressed++;

		if (llch->llch_uncompr_size == chb[i].cch_chunksize ||
		    chb[i].cch_offset + llch->llch_uncompr_size >= la2->la_size)
			continue;
		/* we can't overwrite a chunk with a smaller compressed one,
		 * ask client to resend uncompressed data */
		GOTO(out, rc = -EAGAIN);
	}

	/* we have to copy all pages as this is the first and only RMW
	 * which needs to save the whole chunk uncompressed.
	 * XXX: actually this is not quite true for tails */
	LASSERT(chb);
	LASSERT(info->fti_chunk_nr > 0);
	for (i = 0; i < info->fti_chunk_nr; i++) {
		void *src, *dst;

		if (chb[i].cch_temp_pages == NULL)
			continue;

		chunks_rmw++;
		bytes_rmw += chb[i].cch_nr * PAGE_SIZE;
		bytes_user_rmw += chb[i].cch_len;

		LASSERT(chb[i].cch_compressed == 0);
		for (j = 0; j < chb[i].cch_nr; j++) {
			LASSERT(chb[i].cch_lnb[j].lnb_page);
			LASSERT(chb[i].cch_temp_pages[j]);
			src = kmap(chb[i].cch_temp_pages[j]);
			dst = kmap(chb[i].cch_lnb[j].lnb_page);
			memcpy(dst, src, chb[i].cch_lnb[j].lnb_len);
			kunmap(chb[i].cch_lnb[j].lnb_page);
			kunmap(chb[i].cch_temp_pages[j]);
		}
	}

	npages = ofd_grab_lnbs(chb, info->fti_chunk_nr, *lnb, *nr,
			       info->fti_lnb2_bufs, info->fti_lnb_max);

	lprocfs_counter_add(target->obt_compr_stats,
			    LPROC_OFD_COMPR_CHUNK_WRITE_DISK,
			    info->fti_chunk_nr);
	lprocfs_counter_add(target->obt_compr_stats,
			    LPROC_OFD_COMPR_BYTE_WRITE_DISK,
			    npages * PAGE_SIZE);
	lprocfs_counter_add(target->obt_compr_stats,
			    LPROC_OFD_COMPR_BYTE_WRITE_USER,
			    user_bytes);
	if (chunks_compressed)
		lprocfs_counter_add(target->obt_compr_stats,
				    LPROC_OFD_COMPR_CHUNK_WRITE_COMPRESSED,
				    chunks_compressed);
	if (chunks_rmw) {
		lprocfs_counter_add(target->obt_compr_stats,
				    LPROC_OFD_COMPR_CHUNK_RMW,
				    chunks_rmw);
		lprocfs_counter_add(target->obt_compr_stats,
				    LPROC_OFD_COMPR_BYTE_RMW,
				    bytes_rmw);
		lprocfs_counter_add(target->obt_compr_stats,
				    LPROC_OFD_COMPR_BYTE_RMW_USER,
				    bytes_user_rmw);
	}

	/* XXX: decompress every chunk from client - for debugging only */
	if (0) {
		for (i = 0; i < info->fti_chunk_nr; i++) {
			int n;
			if (chb[i].cch_compressed == 0)
				continue;
			if (!is_chunk_start(chb[i].cch_lnb[0].lnb_page, llch, &rc))
				LBUG();
			n = (chb[i].cch_len + (PAGE_SIZE - 1)) >> PAGE_SHIFT;
			for (j = 0; j < n; j++)
				SetPageUptodate(chb[i].cch_lnb[j].lnb_page);
			rc = ofd_decompress_chunk(env, fo, &chb[i], llch);
			LASSERT(rc == 0);

			if (chb[i].cch_temp_pages[0])
				sptlrpc_pool_put_pages_array(chb[i].cch_temp_pages,
						chb[i].cch_temp_nr);
			OBD_FREE(chb[i].cch_temp_pages,
					sizeof(struct page*) * chb[i].cch_temp_nr);
			chb[i].cch_temp_pages = NULL;
		}
		rc = 0;
	}

	if (OBD_FAIL_CHECK(OBD_FAIL_OST_CSDC_WRITE_BAD)) {
		for (i = 0; i < info->fti_chunk_nr; i++) {
			unsigned char *dst;
			if (chb[i].cch_compressed == 0)
				continue;
			dst = kmap(chb[i].cch_lnb[0].lnb_page);
			dst[2000] = 0x5a;
			dst[2001] = 0x6b;
			dst[2003] = 0x7c;
			kunmap(chb[i].cch_lnb[0].lnb_page);
			break;
		}
	}

out:
	*lnb = info->fti_lnb2_bufs;
	*nr = npages;

	RETURN(rc);
}

/*
 * if this chunk is compressed, then we convert it into uncompressed
 * one and let regular truncate do its job.
 */
int ofd_object_punch_compr(const struct lu_env *env, struct ofd_object *fo,
			   __u64 start, __u64 end, struct lu_attr *la)
{
	struct ofd_thread_info *info = ofd_info(env);
	struct niobuf_local *lnb, *orig_lnb = NULL;
	struct dt_object *o = ofd_object_child(fo);
	int chnr = 0, rc, rc2, i, restart, retries = 0;
	struct ofd_device *ofd = ofd_obj2dev(fo);
	struct obd_device *obd = ofd_obd(ofd);
	struct lu_attr *attr = &info->fti_attr2;
	struct filter_fid *ff = &fo->ofo_ff;
	int lnb_nr, maxlnb, chsz;
	struct niobuf_remote rnb;
	struct csdc_chunk *chb;
	struct thandle *th;
	ENTRY;

	attr->la_valid = LA_SIZE;
	rc = dt_attr_get(env, o, attr);
	if (rc)
		RETURN(rc);
	if (start >= attr->la_size)
		RETURN(0);

	chsz = COMPR_GET_CHUNK_SIZE(ff->ff_layout_compr.ol_compr_chunk_log_bits);
	if ((start & (chsz - 1)) == 0)
		RETURN(0);

	/* this truncate is not chunk-aligned, so we may need to
	 * convert this compressed chunk into non-compressed one */
	fo->ofo_compressed = 1;

	maxlnb = lnb_nr = chsz / PAGE_SIZE;
	OBD_ALLOC(orig_lnb, sizeof(*lnb) * maxlnb);
	if (orig_lnb == NULL)
		RETURN(-ENOMEM);
	lnb = orig_lnb;

	rnb.rnb_offset = start;
	rnb.rnb_len = chsz - (start & (chsz - 1));
	rnb.rnb_flags = OBD_BRW_GRANTED;

	rc = ofd_map_niobuf_to_chunks(env, &rnb, 1, &chb, &chnr, chsz, true);
	if (rc)
		GOTO(err, rc);
	ofd_range_lock_chunks(env, fo, chb, chnr);

	rc = ofd_map_chunks_to_lnb_write(env, obd, fo, chb, chnr,
					 DT_BUFS_TYPE_LOCAL);
	if (rc)
		GOTO(err, rc);

	/* if the chunk is not compressed: no need to continue the conversion */
	if (chb->cch_temp_pages == NULL)
		GOTO(err, rc = 0);

	ofd_generate_lnbs_from_chunks(env, &rnb, 1, chb, chnr,
				      lnb, &lnb_nr, true);

	/* reset remaining part of the chunk */
	for (i = 0; i < lnb_nr; i++) {
		void *buf;
		/*
		 * full pages before new size have valid data.
		 * full pages after new size will be discarded anyway.
		 */
		if (lnb[i].lnb_rc < 0) {
			CERROR("%s: can't convert compressed page: rc=%d\n",
			       obd->obd_name, lnb[i].lnb_rc);
			GOTO(err, rc = lnb[i].lnb_rc);
		}
		if (lnb[i].lnb_len == PAGE_SIZE)
			continue;
		buf = kmap(lnb[i].lnb_page);
		memset(buf + lnb[i].lnb_page_offset, 0, lnb[i].lnb_len);
		kunmap(lnb[i].lnb_page);
	}

	rc = ofd_commitrw_write_compr(env, fo, &lnb, &lnb_nr, la);
	if (rc)
		GOTO(err, rc);

retry:
	restart = 0;
	th = ofd_trans_create(env, ofd);
	if (IS_ERR(th))
		GOTO(err, rc = PTR_ERR(th));
	/* XXX: do we need a sync write if ofd_sync_journal set? */

	rc = dt_declare_write_commit(env, o, lnb, lnb_nr, th);
	if (rc)
		GOTO(out_stop, rc);

	/* we don't need a transno for this internal transaction */
	th->th_local = 1;
	rc = ofd_trans_start(env, ofd, fo, th);
	if (rc)
		GOTO(out_stop, rc);

	ofd_write_lock(env, fo);
	if (!ofd_object_exists(fo))
		GOTO(out_stop, rc = -ENOENT);

	rc = dt_write_commit(env, o, lnb, lnb_nr, th, 0);
	if (rc)
		restart = th->th_restart_tran;
	if (rc == -ENOSPC)
		th->th_sync = 1;

	ofd_write_unlock(env, fo);

out_stop:
	rc2 = ofd_trans_stop(env, ofd, th, restart ? 0 : rc);
	if (!rc)
		rc = rc2;
	if (rc == -ENOSPC && retries++ < 3) {
		/* transaction commit can release space */
		goto retry;
	}
	if (restart) {
		retries++;
		goto retry;
	}

err:
	/* XXX: shouldn't we release chunks when the whole truncate is over? */
	ofd_release_chunk_lnb(env, fo, chb, chnr);
	ofd_release_temp_buffers(env, fo, chb, chnr);
	if (orig_lnb)
		OBD_FREE(orig_lnb, sizeof(*lnb) * maxlnb);

	RETURN(rc);
}

int ofd_decompress_chunk(const struct lu_env *env, struct ofd_object *fo,
			 struct csdc_chunk *chb, struct ll_compr_hdr *llch)
{
	int i, srcpages, dstpages = 0, lvl, hdr_size, rc;
	struct ofd_thread_info *info = ofd_info(env);
	struct crypto_comp *cc = NULL;
	ktime_t start = ktime_get();
	enum ll_compr_type type;
	unsigned int buflen;
	void *buf = NULL;

	type = llch->llch_compr_type;
	lvl = llch->llch_compr_level;
	hdr_size = llch->llch_header_size;
	rc = alloc_decompr(ofd_name(ofd_obj2dev(fo)), &type, &lvl, &cc);
	if (rc)
		GOTO(out, rc);

	/* how much memory we need for uncompressed data */
	i = COMPR_CHUNK_MIN_BITS + llch->llch_chunk_log_bits - PAGE_SHIFT;
	chb->cch_temp_nr = dstpages = 1 << i;

	if (!info->fti_pages || dstpages + chb->cch_nr > info->fti_pages_max) {
		if (info->fti_pages)
			OBD_FREE(info->fti_pages,
				 sizeof(struct page *) * info->fti_pages_max);
		info->fti_pages = NULL;
		info->fti_pages_max = dstpages + chb->cch_nr;
		OBD_ALLOC(info->fti_pages,
			  sizeof(struct page *) * info->fti_pages_max);
		if (info->fti_pages == NULL) {
			CERROR("can't allocate pages ptr\n");
			GOTO(out, rc = -ENOMEM);
		}
	}

	/* collect lnb pages holding compressed data */
	/* XXX: uptodate is not zfs-friendly, need another means */
	for (i = 0, srcpages = 0; i < chb->cch_nr; i++) {
		LASSERT(chb->cch_lnb[i].lnb_page);
		if (!PageUptodate(chb->cch_lnb[i].lnb_page))
			break;
		info->fti_pages[srcpages++] = chb->cch_lnb[i].lnb_page;
	}
	if (srcpages == 0)
		print_compr_structures(env);
	LASSERTF(srcpages > 0, "chunk %llu\n", chb->cch_offset);

	/* get pages for temporary uncompressed data */
	OBD_ALLOC(chb->cch_temp_pages, sizeof(struct page *) * dstpages);
	if (unlikely(chb->cch_temp_pages == NULL))
		GOTO(out, rc = -ENOMEM);
	rc = sptlrpc_pool_get_pages_array(chb->cch_temp_pages, dstpages);
	if (rc)
		GOTO(out, rc);
	LASSERT(srcpages + dstpages <= info->fti_pages_max);
	memcpy((info->fti_pages + srcpages), chb->cch_temp_pages,
		sizeof(struct page *) * dstpages);

	/* setup linear buffer from the pages in lnb */
#ifdef HAVE_VM_MAP_RAM_PROT_ARG
	buf = vm_map_ram(info->fti_pages, srcpages + dstpages, -1, PAGE_KERNEL);
#else
	buf = vm_map_ram(info->fti_pages, srcpages + dstpages, -1);
#endif
	if (buf == NULL) {
		CERROR("can't map %lu: rc=%d\n",
			PAGE_SIZE * (srcpages + dstpages), rc);
		GOTO(out, rc);
	}

	buflen = dstpages * PAGE_SIZE;
	rc = crypto_comp_decompress(cc, buf + llch->llch_header_size,
				    llch->llch_compr_size,
				    buf + (PAGE_SIZE * srcpages),
				    &buflen);
	/* reset the remaining bytes */
	if (rc == 0 && buflen < chb->cch_chunksize)
		memset(buf + (PAGE_SIZE * srcpages) + buflen, 0,
				chb->cch_chunksize - buflen);

	vm_unmap_ram(buf, srcpages + dstpages);

	if (rc != 0) {
		CERROR("fail to uncompress chunk %llu: %d to %d: %px->%px - rc=%d\n",
			chb->cch_offset,
			llch->llch_compr_size, buflen,
			buf + llch->llch_header_size,
			buf + (PAGE_SIZE * srcpages), rc);
		print_compr_structures(env);
		CERROR("COMPRESSION HEADER:\n");
		CERROR(" magic %lx, hdr size %d, type %d, lvl %d, bits %d\n",
		       (unsigned long)llch->llch_magic, llch->llch_header_size,
		       llch->llch_compr_type, llch->llch_compr_level,
		       llch->llch_chunk_log_bits);
		CERROR(" compr size %u, uncompr size %u\n",
		       llch->llch_compr_size, llch->llch_uncompr_size);
	}

out:
	/* the temp.pages will be release in ofd_release_temp_buffers() */
	if (cc)
		crypto_free_comp(cc);

	lprocfs_counter_add(ofd_obd(ofd_obj2dev(fo))->u.obt.obt_compr_stats,
			    LPROC_OFD_COMPR_DECOMPRESSION_TIME,
			    ktime_us_delta(ktime_get(), start));

	RETURN(rc);
}
