/* GPL HEADER START
 *
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License version 2 only,
 * as published by the Free Software Foundation.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * General Public License version 2 for more details (a copy is included
 * in the LICENSE file that accompanied this code).
 *
 * You should have received a copy of the GNU General Public License
 * version 2 along with this program; If not, see
 * http://www.gnu.org/licenses/gpl-2.0.html
 *
 * GPL HEADER END
 */

/*
 * Copyright (c) 2023, DataDirect Networks Inc, all rights reserved.
 * Author: Artem Blagodarenko <ablagodarenko@whamcloud.com>
 * Author: Patrick Farrell <pfarrell@whamcloud.com>
 */

/*
 * Whenever possible, the client handles compression and decompression, but
 * there are two cases where the server must assist.
 *
 * 1. Unaligned reads.  The client attempts to always send chunk aligned reads,
 * but sometimes it must send an unaligned read to the server.
 * 2. Writes into existing compressed chunks.  If a write does not cover an
 * entire compressed chunk, we must do a chunk level read-modify-write to
 * complete the write.  We do this on the server.
 *
 * Both of these are types of unaligned IO, in that the IO doesn't match up
 * 100% to compression chunks.
 *
 * In both cases, the server must read the necessary chunks from disk,
 * decompress them, then do the transfer (either to the client for reads or
 * from the client on writes).  In the case of writes, the server must then
 * write the complete chunk to disk.  (The server will eventually recompress
 * the data, but this isn't finished yet.)
 *
 * The server receives a set of remote niobufs describing the IO from the
 * client.  Each remote niobuf (rnb) describes a range of data the client
 * wants to do IO to.
 *
 * These are translated to a set of local niobufs on the server, which are used
 * to do the server side IO.  With compression, we must always read or write
 * complete chunks.
 *
 * So we walk these remote niobufs and identify unaligned IO requests (in
 * ofd_preprw_read/write), then round them to chunk size. The server then
 * reads the necessary data from storage - for reads, this is the entire range;
 * for writes, this is just the chunks which have unaligned IO.
 *
 * The local niobufs now contain a set of complete chunks with the raw data
 * from disk.  We need to decompress the chunks for unaligned IO, but leave the
 * other chunks unmodified.  (For write, those chunks were not read from disk,
 * for reads, they will be decompressed by the client.)
 *
 * So, in obd_compression, we use the remote niobufs to identify unaligned
 * accesses from the client.  We then walk the local niobufs, identify the
 * chunks which match the unaligned IO from the client, and decompress them
 * 'in place'.
 *
 * The decompression uses temporary buffers, but the decompressed data is
 * placed back in the local niobuf.  (If the data is uncompressed on disk, we
 * of course do not decompress it.  This happens for incompressible data.)
 *
 * Now the local niobuf is ready for transfer - either to be sent to the client
 * or to be updated by data from the client.  For reads, the aligned portion of
 * the IO contains raw data from disk for the client to decompress.  For
 * writes, the aligned portion is empty (the client will place data there).
 * For both reads and writes, the portions of the niobuf which correspond to
 * unaligned IO contain decompressed data.
 *
 * However, the local niobuf does not match the range requested by the client -
 * Because of chunk rounding, it's larger than the client asked for.  Normally
 * the local niobuf contains exactly what was asked for, so we checksum and
 * transfer the whole thing.  In this case, we can't.
 *
 * This means we need to identify the subset of the local niobuf where the
 * client tranfer (read from or write to) will occur and present that to the
 * client.
 *
 * In order to do that, we walk the local niobuf and use the remote niobufs
 * (the description of the pages the client needs) and create a special tx
 * niobuf which points to only the pages the client wants. Then we use this
 * tx niobuf for checksum and transfer to/from the client.
 *
 * For reads, we're done.  For writes, we then write all of the data out to
 * disk, including complete chunks for the unaligned areas.
 *
 * In the initial version, we write this to disk uncompressed.  This is
 * sufficient for correctness, but not ideal since it decompresses those areas
 * of the file.  The code for re-compression is not working 100% yet.  This
 * will be updated when that code is in and working.
 */

#define DEBUG_SUBSYSTEM S_SEC

#include <lustre_debug.h>
#include <linux/falloc.h>
#include <lustre_crypto.h>
#include <lustre_compr.h>
#include <lustre_sec.h>
#include <linux/crc32.h>

/* "one-shot" try to load our own compression modules
 * the first time that a compressed file is accessed
 */
static bool tried_llz4_load = false;
static bool tried_lgzip_load = false;
static bool tried_lzstd_load = false;

/* rounds buf_start and buf_end to chunk size */
void chunk_round(__u64 *buf_start, __u64 *buf_end, int chunk_size)
{
	__u64 orig_start = *buf_start;
	__u64 orig_end = *buf_end;

	*buf_start = round_down(*buf_start, chunk_size);
	*buf_end = round_up(*buf_end, chunk_size);

	if (*buf_start != orig_start || *buf_end != orig_end) {
		CDEBUG(D_SEC, "ROUNDED: buf_start %llu, buf_end %llu\n",
		       *buf_start, *buf_end);
	}
}
EXPORT_SYMBOL(chunk_round);

static inline const char *crypto_name_from_type(enum ll_compr_type type,
						unsigned int level)
{
	switch (type) {
	case LL_COMPR_TYPE_NONE:
	case LL_COMPR_TYPE_SPEC_NONE:
		return "none";
	case LL_COMPR_TYPE_GZIP:
		return "deflate";
	case LL_COMPR_TYPE_LZ4FAST:
		return "lz4";
	case LL_COMPR_TYPE_LZ4HC:
		if (level < LZ4HC_MIN_CLEVEL - 1)
			return "lz4";
		return "lz4hc";
	case LL_COMPR_TYPE_LZO:
		return "lzo";
	case LL_COMPR_TYPE_ZSTD:
		return "zstd";
	case LL_COMPR_TYPE_ZSTDFAST:
		return "zstdfast";
	default:
		return "unknown";
	}
}

static void load_crypto_module(enum ll_compr_type type)
{
	/* Always try to use our built-in modules.
	 * Do not check request_module ret code, this is best effort
	 * as it will fail back to kernel's modules.
	 */
	if ((type == LL_COMPR_TYPE_LZ4FAST || type == LL_COMPR_TYPE_LZ4HC) &&
	    unlikely(!tried_llz4_load)) {
		/* lz4 and lz4hc are siblings, treat them together */
		request_module(LLZ4FAST_MOD_NAME);
		request_module(LLZ4HC_MOD_NAME);
		tried_llz4_load = true;
	} else if (type == LL_COMPR_TYPE_GZIP && unlikely(!tried_lgzip_load)) {
		request_module(LGZIP_MOD_NAME);
		tried_lgzip_load = true;
	} else if ((type == LL_COMPR_TYPE_ZSTD ||
		     type == LL_COMPR_TYPE_ZSTDFAST) &&
		    unlikely(!tried_lzstd_load)) {
		request_module(LZSTD_MOD_NAME);
		tried_lzstd_load = true;
	}
}

static int __alloc_compr(struct client_obd *cli, const char *obdname,
			 enum ll_compr_type *type, unsigned int *lvl,
			 struct crypto_comp **cc, bool decompress)
{
	const char *obd_name;
	enum ll_compr_type compr_type_best = LL_COMPR_TYPE_GZIP;
	unsigned int compr_best_lvl = 9;
	enum ll_compr_type compr_type_fast = LL_COMPR_TYPE_LZ4FAST;
	unsigned int compr_fast_lvl = LL_LZ4FAST_MAX_LEVEL;
	int ret = 0;

	ENTRY;

	if (OBD_FAIL_CHECK(OBD_FAIL_OSC_WRONG_COMP_ALG))
		GOTO(out, ret = -EIO);

	/*
	 * We should never have a chunk that is actually compressed with BEST
	 * or FAST type, so it should never apply during decompression.
	 */
	LASSERT(ergo(decompress, *type != LL_COMPR_TYPE_BEST &&
		     *type != LL_COMPR_TYPE_FAST));

	if (cli) {
		obd_name = cli->cl_import->imp_obd->obd_name;
		compr_type_best = cli->cl_compr_type_best;
		compr_best_lvl = cli->cl_compr_best_level;
		compr_type_fast = cli->cl_compr_type_fast;
		compr_fast_lvl = cli->cl_compr_fast_level;
	} else {
		obd_name = obdname;
	}

	if (*type == LL_COMPR_TYPE_BEST) {
		*type = compr_type_best;
		*lvl = compr_best_lvl;
	} else if (*type == LL_COMPR_TYPE_FAST) {
		*type = compr_type_fast;
		/* lz4fast - our usual 'fast' interprets level as an
		 * acceleration factor, so special case that
		 */
		if (*type == LL_COMPR_TYPE_LZ4FAST)
			*lvl = LL_LZ4FAST_MAX_LEVEL;
		else
			*lvl = compr_fast_lvl;
	}

	load_crypto_module(*type);

again:
	ret = 0;
	*cc = crypto_alloc_comp(crypto_name_from_type(*type, *lvl), 0, 0);
	if (IS_ERR(*cc)) {
		ret = PTR_ERR(*cc);
		CERROR("Cannot initialize compressor %i, error %i.\n", *type,
		       ret);
		/* decompression must be performed with the requested type */
		if (decompress) {
			CERROR("Decompression failed, rc = %d\n", ret);
			GOTO(out, ret);
		}
		/* LZO should be universally available, so we fall back to LZO,
		 * and it's not available, we just give up on compression.
		 */
		if (*type == LL_COMPR_TYPE_LZO) {
			CWARN("%s: LZO(%i) crypto setup failed, left plain: rc = %d\n",
			      obd_name, *type, ret);
			*type = LL_COMPR_TYPE_NONE;
			GOTO(out, ret = 1);
		} else if (*type != compr_type_fast) {
			CWARN("%s: type %i crypto setup failed, try FAST(%i): rc = %d\n",
			      obd_name, *type, compr_type_fast, ret);
			*type = compr_type_fast;
			goto again;
		} else {
			CWARN("%s: type %i crypto setup failed, try LZO(%i): rc = %d\n",
			      obd_name, *type, LL_COMPR_TYPE_LZO, ret);
			*type = LL_COMPR_TYPE_LZO;
			goto again;
		}
	}

out:
	if (ret) {
		*cc = NULL;
	} else /* success */ {
		if (*lvl != -1)
			ll_crypto_comp_set_level(*cc, *lvl);
		CDEBUG(D_SEC, "%s: crypto_comp allocated, type %i, level %i\n",
		       obd_name, *type, *lvl);
	}

	RETURN(ret);
}

int alloc_compr(struct client_obd *cli, enum ll_compr_type *type,
		unsigned int *lvl, struct crypto_comp **cc)
{
	return __alloc_compr(cli, NULL, type, lvl, cc, false);
}
EXPORT_SYMBOL(alloc_compr);

int alloc_decompr(const char *obd_name, enum ll_compr_type *type,
		unsigned int *lvl, struct crypto_comp **cc)
{
	return __alloc_compr(NULL, obd_name, type, lvl, cc, true);
}
EXPORT_SYMBOL(alloc_decompr);

/*
 * The minimum delta between compressed and plain data to
 * use the compressed one.
 */

static __u32 compr_header_csum(struct ll_compr_hdr *header)
{
	int offset = offsetof(struct ll_compr_hdr, llch_hdr_csum);
	__u32 csum32;
	/* let's skip llch_hdr_csum value and crc 0 instead */
	__u32 dummy_csum = 0;

	csum32 = crc32(~0, (unsigned char *)header,
			    offset);
	csum32 = crc32(csum32, (unsigned char *)&dummy_csum,
		       sizeof(dummy_csum));
	offset += sizeof(dummy_csum);

	if (offset < header->llch_header_size) {
		csum32 = crc32(csum32, (unsigned char *)header + offset,
			       header->llch_header_size - offset);
	}

	return csum32;
}

int compress_chunk(const char *obd_name, struct crypto_comp *cc,
		   const unsigned char *in, unsigned int in_len,
		   unsigned char *out, unsigned int *out_len,
		   enum ll_compr_type type, unsigned int lvl,
		   unsigned int chunk_bits)
{
	struct ll_compr_hdr *llch;
	unsigned int len = *out_len - sizeof(*llch);
	int effective_uncompr_size;
	int effective_compr_size;
	int rc;

	/* the uncompressed data is shorter than the minimum effective
	 * compressed size, so don't bother compressing
	 */
	if (in_len <= LL_COMPR_GAP) {
		*out_len = in_len;
		return 0;
	}

	rc = crypto_comp_compress(cc, in, in_len,
				  out + sizeof(*llch),
				  &len);
	if (rc) {
		*out_len = in_len;
		CDEBUG(D_SEC, "%s: Compression failed, type %i, lvl %d, %d\n",
		       obd_name, type, lvl, rc);
		return 0;
	}

	/* round the sizes up to the nearest block before comparing */
	effective_compr_size = round_up(len + sizeof(*llch), LL_COMPR_GAP);
	effective_uncompr_size = round_up(in_len, LL_COMPR_GAP);

	if (effective_compr_size >= effective_uncompr_size) {
		CDEBUG(D_SEC,
		       "Compressed %u + overhead %u > plain %u + overhead %u, leaving uncompressed\n",
		       len, effective_compr_size - len, in_len,
		       effective_uncompr_size - in_len);
		*out_len = in_len;
		return 0;
	}

	llch = (struct ll_compr_hdr *)out;
	llch->llch_magic = LLCH_MAGIC;
	llch->llch_header_size = sizeof(*llch);
	llch->llch_compr_type = type;
	llch->llch_compr_level = lvl;
	/* chunk_log_bits from chunk_bits */
	llch->llch_chunk_log_bits = chunk_bits - COMPR_CHUNK_MIN_BITS;
	llch->llch_flags = 0;
	llch->llch_compr_size = len;
	llch->llch_uncompr_size = in_len;
	llch->llch_reserved = 0;
	llch->llch_compr_csum = 0;
	llch->llch_hdr_csum = compr_header_csum(llch);

	*out_len = len + sizeof(*llch);

	return 1;
}
EXPORT_SYMBOL(compress_chunk);

static int chunk_header_csum_valid(struct ll_compr_hdr *header)
{
	__u32 csum32;

	csum32 = compr_header_csum(header);
	if (csum32 != header->llch_hdr_csum) {
		CDEBUG(D_SEC, "Header csum mismatch %x != %x\n",
		       cpu_to_le32(csum32), header->llch_hdr_csum);
		return 0;
	}

	return 1;
}

int is_chunk_start(struct page *page, struct ll_compr_hdr *ret_header, int *rc)
{
	struct ll_compr_hdr *header;
	int retval = 1;
	ENTRY;

	*rc = 0;
	if (page == NULL)
		RETURN(0);
	header = (struct ll_compr_hdr *)kmap_atomic(page);

	if (header->llch_magic != LLCH_MAGIC) {
		retval  = 0;
		/* If the magic is found but most fields are invalid, it
		 * implies that the data is likely uncompressed and should
		 * be passed through unmodified.
		 */
	} else if (header->llch_hdr_csum != 0 &&
		   !(chunk_header_csum_valid(header))) {
		CDEBUG(D_SEC, "Magic found but header csum invalid\n");
		retval = 0;
		/* If the magic is valid but a few fields are invalid, it
		 * suggests that the valid compressed chunk is corrupted and
		 * -EUCLEAN should be returned when reading it.
		 */
	} else if (header->llch_compr_size >=
		   COMPR_GET_CHUNK_SIZE(header->llch_chunk_log_bits) ||
		   /* Asume here that ll_compr_hdr will grow less then
		    * 4 times from original size
		    */
		   header->llch_header_size > sizeof(header) * 4 ||
		   header->llch_compr_type > LL_COMPR_TYPE_MAX) {

		if (header->llch_hdr_csum == 0) {
			CDEBUG(D_SEC, "No csum, sanity failed, skipping\n");
			retval = 0;
		} else {
			retval = 0;
			*rc = -EUCLEAN;
		}
	}

	*ret_header = *header;

	kunmap_atomic(header);

	RETURN(retval);
}
EXPORT_SYMBOL(is_chunk_start);

int decompress_chunk(const char *obd_name, struct crypto_comp *cc,
		     unsigned char *in, unsigned int in_len,
		     unsigned char *out, unsigned int *out_len,
		     enum ll_compr_type type, unsigned int lvl)
{
	int rc = 0;

	CDEBUG(D_SEC, "in_len %u, out_len %u, type %d, lvl %u\n", in_len,
	       *out_len, type, lvl);

	rc = crypto_comp_decompress(cc, in, in_len, out, out_len);
	if (rc) {
		CERROR("%s: Compression error : rc = %d\n", obd_name, rc);
		goto fail;
	}

fail:
	return rc;
}
EXPORT_SYMBOL(decompress_chunk);

int merge_chunk(struct brw_page **pga, struct niobuf_local *lnbs,
		int first, int count, char *merged, unsigned int *size)
{
	struct brw_page *brwpg;
	struct page *vmpage;
	__u64 offset;
	int pg_len;
	char *kaddr;
	int i;

	*size = 0;
	for (i = 0; i < count; i++) {
		if (pga) {
			brwpg = pga[first + i];
			vmpage = brwpg->pg;
			pg_len = brwpg->count;
			offset = brwpg->off;
		} else {
			struct niobuf_local lnb = lnbs[first + i];;

			CDEBUG(D_SEC, "lnb %d, at %llu, len %d, rc %d\n",
			       first + i, lnb.lnb_file_offset, lnb.lnb_len,
			       lnb.lnb_rc);
			/* can't merge pages with errors in the data */
			if (lnb.lnb_rc < 0)
				return lnb.lnb_rc;
			/* there's no data in this lnb, so stop merging here */
			if (lnb.lnb_rc == 0)
				break;
			vmpage = lnb.lnb_page;
			pg_len = lnb.lnb_len;
			offset = lnb.lnb_file_offset;
		}
		CDEBUG(D_SEC, "page %pK [%d] at offset %llu\n",
		       vmpage, pg_len, offset);
		kaddr = kmap_atomic(vmpage);
		memcpy(merged + i * PAGE_SIZE, kaddr, pg_len);
		kunmap_atomic(kaddr);
		*size += pg_len;
	}

	return i;
}
EXPORT_SYMBOL(merge_chunk);

void unmerge_chunk(struct brw_page **pga, struct niobuf_local *lnb, int first,
		   int count, char *merged, unsigned int size,
		   int pages_per_chunk)
{
	struct brw_page *brwpg;
	struct page *vmpage;
	unsigned int left = size;
	int *pg_len;
	__u64 offset;
	char *kaddr;
	int i;

	for (i = 0; i < count; i++) {
		if (pga) {
			brwpg = pga[first + i];
			vmpage = brwpg->pg;
			pg_len = &brwpg->count;
			offset = brwpg->off;
		} else {
			vmpage = lnb[first + i].lnb_page;
			pg_len = &lnb[first + i].lnb_len;
			offset = lnb[first + i].lnb_file_offset;
		}
		CDEBUG(D_SEC, "page %p [%d] at offset %llu\n",
		       vmpage, *pg_len, offset);

		kaddr = kmap_atomic(vmpage);
		memcpy(kaddr, merged + (i << PAGE_SHIFT),
		       PAGE_SIZE);
		if (left < PAGE_SIZE) {
			*pg_len = left;
			left = 0;
			memset(kaddr + *pg_len, 0, PAGE_SIZE - *pg_len);
		} else {
			*pg_len = PAGE_SIZE;
			left -= PAGE_SIZE;
		}
		kunmap_atomic(kaddr);
		/* we just put data in this page, so set the rc
		 * and disable guard from disk
		 */
		if (lnb) {
			lnb[first + i].lnb_rc = *pg_len;
			lnb[first + i].lnb_guard_disk = 0;
		}
		CDEBUG(D_SEC, "pg_len: %u, left %u\n",
		       *pg_len, left);
	}
	LASSERT(left == 0);
	if (lnb) {
		for (; first + i < pages_per_chunk; i++) {
			CDEBUG(D_SEC, "no data in page %d at %llu, lnb_rc %d - clear page\n",
			       i, lnb[first + i].lnb_file_offset, lnb[first + i].lnb_rc);
			memset(kmap(lnb[i].lnb_page), 0, PAGE_SIZE);
			kunmap(lnb[i].lnb_page);
			lnb[i].lnb_guard_disk = 0;
		}
	}
}
EXPORT_SYMBOL(unmerge_chunk);

int compress_str2type(char *s_type, enum ll_compr_type *type,
		      char *s_level, int *level)
{
	bool found = false;
	int i;
	int rc = 0;

	for (i = LL_COMPR_TYPE_NONE; i < LL_COMPR_TYPE_MAX; i++) {
		if (compr_type_table[i].ctn_name == NULL)
			continue;
		if (strcmp(s_type, compr_type_table[i].ctn_name) == 0) {
			*type = compr_type_table[i].ctn_compr_type;

			if (s_level && level) {
				rc = kstrtoint(s_level, 0, level);
				if (rc)
					return rc;

				if (compr_type_table[i].ctn_from_compr_level)
					*level = compr_type_table[i].
						ctn_from_compr_level(*level);
			}
			found = true;
			break;
		}
	}

	if (!found)
		return -EINVAL;

	return rc;
}
EXPORT_SYMBOL(compress_str2type);
