#!/bin/bash
#
# Tests for laudit and laudit-report
#
set -e

ONLY=${ONLY:-"$*"}

LUSTRE=${LUSTRE:-$(dirname $0)/..}
. $LUSTRE/tests/test-framework.sh
init_test_env $@
. ${CONFIG:=$LUSTRE/tests/cfg/$NAME.sh}
init_logging

# bug number for skipped test:
ALWAYS_EXCEPT="$SANITY_LAUDIT_EXCEPT "
# UPDATE THE COMMENT ABOVE WITH BUG NUMBERS WHEN CHANGING ALWAYS_EXCEPT!

! remote_mds_nodsh || skip_env "remote MDS with nodsh"
! remote_ost_nodsh || skip_env "remote OSS with nodsh"

# check if laudit and laudit-report are installed on clients
for t in laudit laudit-report; do
	do_nodes $CLIENTS "which $t" &>/dev/null ||
		skip_env "$t is not installed on client"
done

# laudit configuration
LAUDIT="laudit"
LAUDIT_REPORT="laudit-report"
LAUDIT_DUMP_PATH=$TMP/audit
LAUDIT_CONF_FILE=$TMP/laudit.conf

build_test_filter
check_and_setup_lustre
check_runas_id $RUNAS_ID $RUNAS_ID $RUNAS

setup_changelogs() {
	changelog_register || error "changelog_register failed"
	local cl_user="${CL_USERS[$SINGLEMDS]%% *}"
	changelog_users $SINGLEMDS | grep -q $cl_user ||
		error "User $cl_user not found in changelog_users"
	changelog_chmask "ALL"
}

cleanup_sanity_laudit() {
	rm -f $LAUDIT_CONF_FILE
	rm -rf $LAUDIT_DUMP_PATH
	killall laudit
}

generate_conf_file() {
	cat <<EOF > $LAUDIT_CONF_FILE
{
    "fs_name": "$FSNAME",
    "mount": "$MOUNT",
    "dump_path": "$LAUDIT_DUMP_PATH",
    "mdts": [
EOF
	for i in $(seq 1 $MDSCOUNT); do
		echo "      {\"mdt_idx\": $((i-1)), \"reader_id\": \"${CL_USERS[mds$i]%% *}\"}," >> $LAUDIT_CONF_FILE
	done
	cat <<EOF >> $LAUDIT_CONF_FILE
    ],
    "parse_interval_sec": 10,
    "sync_every_n_entries": 1000,
    "max_syncs_before_sleep": 10
}
EOF
}

create_simple_files() {
	local dir=$1

	changelog_clear 0 || error "changelog_clear failed"
	$RUNAS touch $dir/$tfile
	$RUNAS cat $dir/$tfile
	changelog_dump
}

check_events() {
	grep 01CREAT $* || error "01CREAT event not found"
	grep -E "10OPEN.*j=touch.*m=-w-" $* || error "10OPEN event not found (1)"
	grep -E "11CLOSE.*j=touch" $* || error "11CLOSE event not found (1)"
	grep -E "10OPEN.*j=cat.*m=r--" $* || error "10OPEN event not found (2)"
	grep -E "11CLOSE.*j=cat" $* || error "11CLOSE event not found (2)"
}

check_audit_files() {
	local tfid=$1
	local lfiles

	lfiles=$(find $LAUDIT_DUMP_PATH/users/$RUNAS_ID:$RUNAS_ID/$(date +%Y) \
			-type f)
	[ -n "$lfiles" ] || error "'users' file not present"
	echo "Checking 'users' audit files"
	check_events $lfiles

	lfiles=$(find $LAUDIT_DUMP_PATH/files/$tfid/$(date +%Y) -type f)
	[ -n "$lfiles" ] || error "'files' file not present"
	echo "Checking 'files' audit files"
	check_events $lfiles
}

check_audit_report() {
	local tfid=$1
	local filepath=$2
	local report=$(mktemp)

	$LAUDIT_REPORT -u $RUNAS_ID:$RUNAS_ID $LAUDIT_CONF_FILE > $report ||
		error "$LAUDIT_REPORT -u $RUNAS_ID:$RUNAS_ID failed"
	echo "Checking audit report for user $RUNAS_ID:$RUNAS_ID"
	check_events $report

	$LAUDIT_REPORT -f $tfid $LAUDIT_CONF_FILE > $report ||
		error "$LAUDIT_REPORT -f $tfid failed"
	echo "Checking audit report for FID $tfid"
	check_events $report

	$LAUDIT_REPORT -f $filepath $LAUDIT_CONF_FILE > $report ||
		error "$LAUDIT_REPORT -f $filepath failed"
	echo "Checking audit report for file $filepath"
	check_events $report
}

mkdir $LAUDIT_DUMP_PATH
stack_trap cleanup_sanity_laudit EXIT
setup_changelogs
generate_conf_file

test_1() {
	local tfid
	local lfiles

	$LFS setdirstripe -c1 -i0 $DIR/$tdir
	chmod 777 $DIR/$tdir
	create_simple_files $DIR/$tdir
	rm -rf $LAUDIT_DUMP_PATH/*
	$LAUDIT -p $LAUDIT_CONF_FILE || error "laudit failed"

	tfid=$($LFS path2fid $DIR/$tdir/$tfile)
	check_audit_files $tfid
	check_audit_report $tfid $DIR/$tdir/$tfile

	if [ $MDSCOUNT -ge 2 ]; then
		$LFS setdirstripe -c1 -i1 $DIR/${tdir}2
		chmod 777 $DIR/${tdir}2
		create_simple_files $DIR/${tdir}2
		rm -rf $LAUDIT_DUMP_PATH/*
		$LAUDIT -p $LAUDIT_CONF_FILE || error "laudit failed"

		tfid=$($LFS path2fid $DIR/${tdir}2/$tfile)
		check_audit_files $tfid
		check_audit_report $tfid $DIR/${tdir}2/$tfile
	fi
}
run_test 1 "laudit simple files"

test_2() {
	local tfid
	local lfiles

	$LFS setdirstripe -c1 -i0 $DIR/$tdir
	chmod 777 $DIR/$tdir

	rm -rf $LAUDIT_DUMP_PATH/*
	$LAUDIT -p -d $LAUDIT_CONF_FILE || error "cannot launch laudit"

	create_simple_files $DIR/$tdir
	sleep 20 # twice the parse_interval_sec

	tfid=$($LFS path2fid $DIR/$tdir/$tfile)
	check_audit_files $tfid
	check_audit_report $tfid $DIR/$tdir/$tfile
	killall laudit

	if [ $MDSCOUNT -ge 2 ]; then
		$LFS setdirstripe -c1 -i1 $DIR/${tdir}2
		chmod 777 $DIR/${tdir}2
		rm -rf $LAUDIT_DUMP_PATH/*
		$LAUDIT -p -d $LAUDIT_CONF_FILE || error "cannot launch laudit"
		create_simple_files $DIR/${tdir}2
		sleep 20 # twice the parse_interval_sec

		tfid=$($LFS path2fid $DIR/${tdir}2/$tfile)
		check_audit_files $tfid
		check_audit_report $tfid $DIR/${tdir}2/$tfile
	fi
}
run_test 2 "laudit daemon mode"

complete_test $SECONDS
check_and_cleanup_lustre
exit_status
