#include <stdio.h>
#include <unistd.h>
#include <errno.h>
#include <getopt.h>
#include <stdlib.h>
#include <lustre/lustreapi.h>
#include <linux/lustre/lustre_idl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

void usage(void)
{
	printf("Usage: %s: [OPTION]...\n"
"Copy data from a file on Lustre (specified by fid) to a file specified by path\n"
"\n"
"Mandatory arguments to long options are mandatory for short options too.\n"
"  -d, --direct_io		 use direct I/O\n"
"  -F, --source_fid [fid]	 fid of source file for copy\n"
"  -h, --help			 display this help and exit\n"
"  -l, --lustre_dir [dir]	 path to a directory on Lustre\n"
"  -p, --destination_path [path] path of destination for copy\n"
"  -s, --iosize [size]		 do reads/writes of [size] bytes, must be 1 MiB aligned\n",
"ll_fid_path_copy");
}

static ssize_t copy_data(int src_fd, int dst_fd, size_t iosize,
			 int extra_open_flags)
{
	size_t page_size = sysconf(_SC_PAGESIZE);
	size_t copied_total = 0;
	void *buf = NULL;
	off_t offset = 0;
	ssize_t rc = 0;

	rc = posix_memalign(&buf, page_size, iosize);
	if (rc) {
		fprintf(stderr, "%s: memalign failed: rc = %ld\n",
			program_invocation_short_name, rc);
		return rc;
	}

	while (true) {
		ssize_t rsz;
		ssize_t wsz;

		rsz = pread(src_fd, buf, iosize, offset);
		if (rsz < 0) {
			rc = -errno;
			fprintf(stderr,
				"%s: failed to read from source, rc = %ld\n",
				program_invocation_short_name, rc);
			break;
		}
		/* EOF, copy is done */
		if (rsz == 0)
			break;

retry_write:
		wsz = pwrite(dst_fd, buf, rsz, offset);
		if (wsz < 0) {
			rc = -errno;
			/*
			 * Unaligned direct IO reports error code -EINVAL
			 * on the local file system (such as Ext4).
			 * In this case, fallback to buffered IO any way.
			 */
			if (extra_open_flags & O_DIRECT && rc == -EINVAL) {
				extra_open_flags &= ~O_DIRECT;
				rc = fcntl(dst_fd, F_SETFL, extra_open_flags);
				if (rc < 0) {
					rc = -errno;
					fprintf(stderr, "%s: failed to clear O_DIRECT flag: rc = %ld",
						program_invocation_short_name,
						rc);
					break;
				}
				rc = 0;
				goto retry_write;
			}

			fprintf(stderr,
				"%s: failed to write destination: rc = %ld\n",
				program_invocation_short_name, rc);
			break;
		}

		copied_total += wsz;
		offset += wsz;
	}

	if (rc == 0)
		rc = copied_total;

	free(buf);
	return rc;

}

static ssize_t ll_fid_path_copy(const char *lustre_path,
				const struct lu_fid *src_fid,
				const char *dst_path, size_t iosize,
				int extra_open_flags)
{
	struct stat stbuf;
	int src_fd = -1;
	int dst_fd = -1;
	ssize_t rc = 0;

	src_fd = llapi_open_by_fid(lustre_path, src_fid,
				   O_RDONLY | extra_open_flags);
	if (src_fd < 0) {
		rc = -errno;
		fprintf(stderr,
			"%s: failed to open source %s/"DFID": rc = %ld\n",
			program_invocation_short_name, lustre_path,
			PFID(src_fid), rc);
		return rc;
	}

	rc = fstat(src_fd, &stbuf);
	if (rc < 0) {
		fprintf(stderr,
			"%s: failed to stat source %s/"DFID": rc = %ld\n",
			program_invocation_short_name, lustre_path,
			PFID(src_fid), rc);
		goto out;
	}

	dst_fd = open(dst_path, O_WRONLY | O_LARGEFILE | extra_open_flags);
	if (dst_fd < 0) {
		rc = -errno;
		fprintf(stderr, "%s: failed to open destination %s: rc = %ld\n",
			program_invocation_short_name, dst_path, rc);
		goto out;
	}

	rc = copy_data(src_fd, dst_fd, iosize, extra_open_flags);
	if (rc < 0) {
		errno = -rc;
		fprintf(stderr,
			"%s: failed to copy data from %s/"DFID" to %s: rc = %ld.\n",
			program_invocation_short_name, lustre_path,
			PFID(src_fid), dst_path, rc);
		goto out;
	}

	if (rc != stbuf.st_size) {
		fprintf(stderr,
			"%s: incomplete copy: copied %lu bytes of %lu\n",
			program_invocation_short_name, rc, stbuf.st_size);
		rc = -EIO;
	}
out:
	if (src_fd > 0)
		close(src_fd);

	if (dst_fd > 0)
		close(dst_fd);

	return rc;
}

int main(int argc, char *argv[])
{
	static struct option options[] = {
		{ .name = "direct_io", .has_arg = no_argument, .val = 'd' },
		{ .name = "src_fid", .has_arg = required_argument, .val = 'F' },
		{ .name = "help", .has_arg = no_argument, .val = 'h' },
		{ .name = "lustre_path", .has_arg = required_argument, .val = 'l' },
		{ .name = "dst_path", .has_arg = required_argument, .val = 'p' },
		{ .name = "iosize", .has_arg = required_argument, .val = 's' },
	};
	char *dst_path = NULL;
	char *lustre_path = NULL;
	struct lu_fid src_fid;
	char *fidstr = NULL;
	int extra_open_flags = 0;
	__u32 iosize = 0;
	ssize_t rc;
	int c;

	while ((c = getopt_long(argc, argv, "dF:hl:p:s:", options, NULL)) != -1) {
		switch (c) {
			case 'd':
				extra_open_flags = O_DIRECT;
				break;
			case 'F':
				fidstr = optarg;
				break;
			case 'h':
				usage();
				exit(EXIT_SUCCESS);
				break;
			case 'l':
				lustre_path = optarg;
				break;
			case 'p':
				dst_path = optarg;
				break;
			case 's':
				iosize = strtol(optarg, NULL, 0);
				break;
		}
	}

	if (!fidstr) {
		fprintf(stderr, "%s: Must provide a source fid.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (!dst_path) {
		fprintf(stderr, "%s: Must provide destination path.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (!lustre_path) {
		fprintf(stderr, "%s: Must provide Lustre path.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (iosize == 0) {
		fprintf(stderr, "%s: Must provide iosize.\n",
			program_invocation_short_name);
		usage();
		exit(EXIT_FAILURE);
	}

	if (iosize % (1024 * 1024) != 0) {
		fprintf(stderr, "%s: iosize (%u) must be 1 MiB aligned\n",
			program_invocation_short_name, iosize);
		usage();
		exit(EXIT_FAILURE);
	}

	fprintf(stdout,
		"%s: copying from %s to %s, iosize %d, using %s i/o.\n",
		program_invocation_short_name, fidstr, dst_path, iosize,
		extra_open_flags == 0 ? "buffered" : "direct");

	rc = llapi_fid_parse(fidstr, &src_fid, NULL);
	if (rc < 0) {
		fprintf(stderr, "%s: failed to parse fid: %s\n",
			program_invocation_short_name, fidstr);
		exit(EXIT_FAILURE);
	}


	rc = ll_fid_path_copy(lustre_path, &src_fid, dst_path, iosize,
			      extra_open_flags);
	if (rc < 0)
		exit(EXIT_FAILURE);

	fprintf(stdout,
		"%s: successfully copied %lu bytes from %s to %s.\n",
		program_invocation_short_name, rc, fidstr, dst_path);

	exit(EXIT_SUCCESS);
}
